package MainProgram;

import Interfaces.OpeningPage;

public class InternalAssesmentProjectOrganizer {
    public static void main(String[] args) {
        // TODO code application logic here
        OpeningPage OpeningPagesFrame = new OpeningPage();
        OpeningPagesFrame.setVisible(true);
        OpeningPagesFrame.setLocationRelativeTo(null);
    }
    
}
