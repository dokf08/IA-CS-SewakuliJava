package Interfaces;

import Config.ButtonEditor;
import Config.ButtonRenderer;
import Config.AppConnection;
import Config.LineMessageSender;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.text.SimpleDateFormat;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JFrame;



public class FormPage extends javax.swing.JFrame {

    private Connection conn;
    private int userId;
    private String fullName;
    private int currentEventId; // Added for tracking the selected event

    public FormPage(int userId, String fullName) {
        initComponents();
        this.userId = userId; // Store the current user ID
        this.fullName = fullName;
        displayFullName();
        conn = AppConnection.getConnection();
        getData();
        nonAktifButton();
        aktifButton();
    }
    
    private void displayFullName() {
        // Assuming you have a label to show the full name
        label_greetings.setText("Hello, " + fullName);
    }
    
    private void getData() {
        DefaultTableModel model = (DefaultTableModel) tbl_data.getModel();
        tbl_data.getColumnModel().getColumn(4).setCellRenderer(new ButtonRenderer());
        tbl_data.getColumnModel().getColumn(4).setCellEditor(new ButtonEditor(tbl_data, conn));

        model.setRowCount(0);

        try {
            String sql = "SELECT \"eventid\", \"event_tittle\", \"dates\", \"venue\", \"supervisor\", \"organisasi\", \"category\" FROM \"event\" WHERE \"user_id\" = ?;";
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, userId); // Filter by the current user ID
            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                int eventId = rs.getInt("eventid");
                String tittle = rs.getString("event_tittle");
                String date = rs.getString("dates");
                String venue = rs.getString("venue");

                // Add only the fields you want to show in the table
                Object[] rowData = {eventId, tittle, date, venue, "Details"};
                model.addRow(rowData);
            }
            rs.close();
            st.close();

        } catch (Exception e) {
            e.printStackTrace();  // This will show the exact error in the console
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Main = new javax.swing.JPanel();
        Header = new javax.swing.JPanel();
        btn_back = new javax.swing.JButton();
        btn_logout = new javax.swing.JButton();
        label_greetings = new javax.swing.JLabel();
        img_bg = new javax.swing.JLabel();
        MainPanel = new javax.swing.JPanel();
        label_FillUp = new javax.swing.JLabel();
        label_EventName = new javax.swing.JLabel();
        label_eventdate = new javax.swing.JLabel();
        Venue = new javax.swing.JLabel();
        Supervisor = new javax.swing.JLabel();
        Organization = new javax.swing.JLabel();
        Category = new javax.swing.JLabel();
        Rundown = new javax.swing.JLabel();
        NeedPHS = new javax.swing.JLabel();
        EventOrder = new javax.swing.JLabel();
        txtfield_tittle = new javax.swing.JTextField();
        datechooser_date = new com.toedter.calendar.JDateChooser();
        cb_venue = new javax.swing.JComboBox<>();
        txtfield_supervisor = new javax.swing.JTextField();
        opt_organization = new javax.swing.JComboBox<>();
        opt_category = new javax.swing.JComboBox<>();
        txtfield_rundown = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_data = new javax.swing.JTable();
        btn_add = new javax.swing.JButton();
        btn_update = new javax.swing.JButton();
        btn_delete = new javax.swing.JButton();
        btn_clear = new javax.swing.JButton();
        cb_camcrew = new javax.swing.JCheckBox();
        cb_stage = new javax.swing.JCheckBox();
        cb_stream = new javax.swing.JCheckBox();
        cb_lighting = new javax.swing.JCheckBox();
        cb_display = new javax.swing.JCheckBox();
        cb_sound = new javax.swing.JCheckBox();
        Images_template = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Main.setPreferredSize(new java.awt.Dimension(800, 500));
        Main.setLayout(null);

        Header.setBackground(new java.awt.Color(0, 0, 0));
        Header.setLayout(null);

        btn_back.setBackground(new java.awt.Color(255, 51, 255));
        btn_back.setFont(new java.awt.Font("Raleway", 1, 18)); // NOI18N
        btn_back.setForeground(new java.awt.Color(0, 0, 0));
        btn_back.setText("Back");
        btn_back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_backActionPerformed(evt);
            }
        });
        Header.add(btn_back);
        btn_back.setBounds(570, 30, 100, 40);

        btn_logout.setBackground(new java.awt.Color(255, 51, 255));
        btn_logout.setFont(new java.awt.Font("Raleway", 1, 18)); // NOI18N
        btn_logout.setForeground(new java.awt.Color(0, 0, 0));
        btn_logout.setText("Logout");
        btn_logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_logoutActionPerformed(evt);
            }
        });
        Header.add(btn_logout);
        btn_logout.setBounds(670, 30, 100, 40);

        label_greetings.setFont(new java.awt.Font("Raleway", 1, 24)); // NOI18N
        label_greetings.setForeground(new java.awt.Color(255, 102, 255));
        label_greetings.setText("Greetings");
        Header.add(label_greetings);
        label_greetings.setBounds(90, 30, 490, 40);

        img_bg.setIcon(new javax.swing.ImageIcon("/Users/dokf/Downloads/Internal Assesment CS-4.png")); // NOI18N
        img_bg.setText("jLabel4");
        Header.add(img_bg);
        img_bg.setBounds(0, -10, 800, 500);

        Main.add(Header);
        Header.setBounds(0, 0, 800, 100);

        MainPanel.setBackground(new java.awt.Color(255, 255, 255));
        MainPanel.setMinimumSize(new java.awt.Dimension(800, 390));
        MainPanel.setPreferredSize(new java.awt.Dimension(800, 500));
        MainPanel.setLayout(null);

        label_FillUp.setFont(new java.awt.Font("Helvetica Neue", 1, 24)); // NOI18N
        label_FillUp.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        label_FillUp.setText("Please Fill Up the Form");
        MainPanel.add(label_FillUp);
        label_FillUp.setBounds(40, 10, 290, 30);

        label_EventName.setText("Name of Event");
        MainPanel.add(label_EventName);
        label_EventName.setBounds(40, 50, 100, 17);

        label_eventdate.setText("Date of Event");
        MainPanel.add(label_eventdate);
        label_eventdate.setBounds(40, 100, 100, 17);

        Venue.setText("Venue");
        MainPanel.add(Venue);
        Venue.setBounds(40, 150, 100, 17);

        Supervisor.setText("Supervisor");
        MainPanel.add(Supervisor);
        Supervisor.setBounds(230, 50, 130, 17);

        Organization.setText("Organization");
        MainPanel.add(Organization);
        Organization.setBounds(230, 100, 160, 17);

        Category.setText("Event Category");
        MainPanel.add(Category);
        Category.setBounds(230, 150, 120, 17);

        Rundown.setFont(new java.awt.Font("Raleway", 1, 18)); // NOI18N
        Rundown.setText("Event Rundown");
        MainPanel.add(Rundown);
        Rundown.setBounds(30, 210, 290, 22);

        NeedPHS.setFont(new java.awt.Font("Raleway", 1, 18)); // NOI18N
        NeedPHS.setText("What do you need for PHS?");
        MainPanel.add(NeedPHS);
        NeedPHS.setBounds(30, 280, 290, 22);

        EventOrder.setFont(new java.awt.Font("Helvetica Neue", 1, 18)); // NOI18N
        EventOrder.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        EventOrder.setText("Your Order Event");
        MainPanel.add(EventOrder);
        EventOrder.setBounds(500, 20, 200, 30);

        txtfield_tittle.setToolTipText("");
        txtfield_tittle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtfield_tittleActionPerformed(evt);
            }
        });
        MainPanel.add(txtfield_tittle);
        txtfield_tittle.setBounds(40, 70, 160, 30);

        datechooser_date.setDateFormatString("d MMM, y");
        MainPanel.add(datechooser_date);
        datechooser_date.setBounds(40, 120, 160, 30);

        cb_venue.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Venue", "Auditorium", "Theater", "Lapangan Apel", "Lapangan Bola", "Masjid", "Gereja" }));
        cb_venue.setToolTipText("");
        MainPanel.add(cb_venue);
        cb_venue.setBounds(40, 170, 160, 27);
        MainPanel.add(txtfield_supervisor);
        txtfield_supervisor.setBounds(230, 70, 160, 27);

        opt_organization.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Organization", "MPK", "OSIS", "DEWAN AMBALAN", "PHS", "ROHIS", "ROHKATKRIS", "SERSAN", "PMR", "PIK - R", "GAMAYAKSA", " ", " ", " " }));
        opt_organization.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opt_organizationActionPerformed(evt);
            }
        });
        MainPanel.add(opt_organization);
        opt_organization.setBounds(230, 120, 160, 27);

        opt_category.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Category", "Performance", "Stadium Generale", "Games Night", "Formal Event", "Video Production", "Photo Production / Photoshoot" }));
        MainPanel.add(opt_category);
        opt_category.setBounds(230, 170, 160, 27);
        MainPanel.add(txtfield_rundown);
        txtfield_rundown.setBounds(30, 240, 340, 27);

        tbl_data.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Event Name", "Date", "Venue", "Details"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_data.setGridColor(new java.awt.Color(204, 204, 204));
        tbl_data.setRowHeight(30);
        tbl_data.getTableHeader().setReorderingAllowed(false);
        tbl_data.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_dataMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_data);
        if (tbl_data.getColumnModel().getColumnCount() > 0) {
            tbl_data.getColumnModel().getColumn(0).setResizable(false);
            tbl_data.getColumnModel().getColumn(0).setPreferredWidth(20);
        }

        MainPanel.add(jScrollPane1);
        jScrollPane1.setBounds(420, 50, 360, 290);

        btn_add.setText("Submit");
        btn_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_addActionPerformed(evt);
            }
        });
        MainPanel.add(btn_add);
        btn_add.setBounds(420, 350, 90, 27);

        btn_update.setText("Update");
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });
        MainPanel.add(btn_update);
        btn_update.setBounds(510, 350, 90, 27);

        btn_delete.setText("Delete");
        btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_deleteActionPerformed(evt);
            }
        });
        MainPanel.add(btn_delete);
        btn_delete.setBounds(600, 350, 90, 27);

        btn_clear.setText("Clear");
        btn_clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clearActionPerformed(evt);
            }
        });
        MainPanel.add(btn_clear);
        btn_clear.setBounds(690, 350, 90, 27);

        cb_camcrew.setText("Camera Crew");
        MainPanel.add(cb_camcrew);
        cb_camcrew.setBounds(40, 350, 140, 21);

        cb_stage.setText("Stage Manager");
        MainPanel.add(cb_stage);
        cb_stage.setBounds(180, 330, 140, 21);

        cb_stream.setText("Streaming");
        MainPanel.add(cb_stream);
        cb_stream.setBounds(180, 310, 140, 21);

        cb_lighting.setText("Lighting");
        MainPanel.add(cb_lighting);
        cb_lighting.setBounds(180, 350, 140, 21);

        cb_display.setText("Display");
        cb_display.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_displayActionPerformed(evt);
            }
        });
        MainPanel.add(cb_display);
        cb_display.setBounds(40, 310, 140, 21);

        cb_sound.setText("Sound Engineer");
        MainPanel.add(cb_sound);
        cb_sound.setBounds(40, 330, 140, 21);

        Images_template.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/img_background.png"))); // NOI18N
        MainPanel.add(Images_template);
        Images_template.setBounds(0, -100, 800, 500);

        Main.add(MainPanel);
        MainPanel.setBounds(0, 100, 800, 400);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Main, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Main, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtfield_tittleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfield_tittleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtfield_tittleActionPerformed

    
    private void sendEmailToAdmin(String adminEmail, String subject, String bodyEmail) {
        String emailSender = AppConnection.getEmailSender(); // Use your existing email sender method
        String passwordSender = AppConnection.getPasswordSender();

        // Setup properties for email
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication(){
                return new PasswordAuthentication(emailSender, passwordSender);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(emailSender));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(adminEmail));
            message.setSubject(subject);
            message.setText(bodyEmail); // Send the full email body including job assignments

            Transport.send(message);
            System.out.println("Email sent successfully to " + adminEmail);
        } catch (MessagingException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error sending email to " + adminEmail + ": " + e.getMessage());
        }
    }
    private void btn_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_addActionPerformed
        String tittle = txtfield_tittle.getText();
        java.util.Date selectedDate = datechooser_date.getDate(); // Get the selected date from JDateChooser
        java.sql.Date sqlDate = selectedDate != null ? new java.sql.Date(selectedDate.getTime()) : null; // Convert to java.sql.Date

        String venue = cb_venue.getSelectedItem().toString();
        String supervisor = txtfield_supervisor.getText();
        String organization = opt_organization.getSelectedItem().toString();
        String category = opt_category.getSelectedItem().toString();
        String rundown = txtfield_rundown.getText();

        // Get the values of the checkboxes for the jobs
        int needDisplay = cb_display.isSelected() ? 1 : 0;
        int needSound = cb_sound.isSelected() ? 1 : 0;
        int needStage = cb_stage.isSelected() ? 1 : 0;
        int needCamCrew = cb_camcrew.isSelected() ? 1 : 0;
        int needLighting = cb_lighting.isSelected() ? 1 : 0;
        int needStream = cb_stream.isSelected() ? 1 : 0;

        if (tittle.isEmpty() || sqlDate == null || supervisor.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields must be filled out!", "Validation", JOptionPane.ERROR_MESSAGE);
            return;
        } else if (venue.equals("Select Venue")) {
            JOptionPane.showMessageDialog(this, "Select the Venue of your Event!", "Validation", JOptionPane.ERROR_MESSAGE);
            return;
        } else if (organization.equals("Select Organization")) {
            JOptionPane.showMessageDialog(this, "Select the Organization!", "Validation", JOptionPane.ERROR_MESSAGE);
            return;
        } else if (category.equals("Select Category")) {
            JOptionPane.showMessageDialog(this, "Select Your Category of Event!", "Validation", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Insert the event details into the database
            String sql = "INSERT INTO \"event\" (\"user_id\", \"event_tittle\", \"dates\", \"venue\", \"supervisor\", \"organisasi\", \"category\", \"rundown\", \"display\", "
                        + "\"sound_engineer\", \"stage_manager\", \"cam_crew\", \"lighting\", \"streaming\", \"status\") "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, userId); // Link the event to the current user
            st.setString(2, tittle);
            st.setDate(3, sqlDate); // Use java.sql.Date for the dates column
            st.setString(4, venue);
            st.setString(5, supervisor);
            st.setString(6, organization);
            st.setString(7, category);
            st.setString(8, rundown);

            // Set the checkbox values for crew needs
            st.setInt(9, needDisplay);
            st.setInt(10, needSound);
            st.setInt(11, needStage);
            st.setInt(12, needCamCrew);
            st.setInt(13, needLighting);
            st.setInt(14, needStream);

            // Set the initial status of the event
            st.setString(15, "Not Full");

            int rowInserted = st.executeUpdate();
            if (rowInserted > 0) {
                JOptionPane.showMessageDialog(this, "Data successfully added");
                resetForm();
                getData();

                // Prepare message for LINE (short format)
                String lineJobDetails = "";
                if (needDisplay == 1) lineJobDetails += "✨ Display\\n";
                if (needSound == 1) lineJobDetails += "🔊 Sound Engineer\\n";
                if (needStage == 1) lineJobDetails += "🎭 Stage Manager\\n";
                if (needCamCrew == 1) lineJobDetails += "📸 Camera Crew\\n";
                if (needLighting == 1) lineJobDetails += "💡 Lighting\\n";
                if (needStream == 1) lineJobDetails += "🎥 Streaming\\n";

                String lineMessage = "🎉 A new event has just been created by " + fullName + " 🎉\\n\\n" +
                                     "📝 Event Title: " + tittle + "\\n" +
                                     "📅 Date: " + sqlDate + "\\n" +
                                     "🏟️ Venue: " + venue + "\\n" +
                                     "👩‍🏫 Supervisor: " + supervisor + "\\n" +
                                     "💼 Organization: " + organization + "\\n" +
                                     "🎨 Category: " + category + "\\n" +
                                     "📜 Rundown: " + rundown + "\\n\\n" +
                                     "Jobs available:\\n" + lineJobDetails;

                // Send message to LINE group
                sendLineGroupMessage(lineMessage);

                // Prepare email content (sarcastic, long format)
                String emailJobDetails = "";
                if (needDisplay == 1) emailJobDetails += "✨ Display (Because who doesn’t want to stare at screens all day?)\n";
                if (needSound == 1) emailJobDetails += "🔊 Sound Engineer (Turn those dials and pretend you know what you're doing 😏)\n";
                if (needStage == 1) emailJobDetails += "🎭 Stage Manager (Keep things from falling apart — good luck!)\n";
                if (needCamCrew == 1) emailJobDetails += "📸 Camera Crew (Don’t miss a single awkward moment!)\n";
                if (needLighting == 1) emailJobDetails += "💡 Lighting (Make sure no one’s in the dark — literally)\n";
                if (needStream == 1) emailJobDetails += "🎥 Streaming (Go viral or go home!)\n";

                String emailMessage = "🎉 Hold on tight, a new event has just been created by none other than the fabulous " + fullName + " 🎉!\n\n" +
                                      "Here are the details of this once-in-a-lifetime event:\n\n" +
                                      "📝 Event Title: " + tittle + "\n" +
                                      "📅 Date: " + sqlDate + "\n" +
                                      "🏟️ Venue: " + venue + "\n" +
                                      "👩‍🏫 Supervisor: " + supervisor + "\n" +
                                      "💼 Organization: " + organization + "\n" +
                                      "🎨 Category: " + category + "\n" +
                                      "📜 Rundown: " + rundown + "\n\n" +
                                      "But wait, there’s more! These jobs are up for grabs:\n\n" + emailJobDetails;

                // Send email to admins
                sendAdminEmailToAll(tittle, sqlDate, venue, supervisor, organization, category, rundown, emailJobDetails);
            }

            st.close();

        } catch (Exception e) {
            e.printStackTrace();  // This will show the exact error in the console
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }//GEN-LAST:event_btn_addActionPerformed

    private void sendLineGroupMessage(String message) {
        try {
            // Truncate the message to a maximum of 500 characters
            String truncatedMessage = truncateMessage(message, 500);

            // Replace with your group ID (the one you got from the webhook data)
            String groupId = "Ca798616dc6c9be451e9ba229f69b2d49";

            // Call the LineGroupMessageSender to send the message
            LineMessageSender.sendMessageToGroup(groupId, truncatedMessage);
        } catch (Exception e) {
            e.printStackTrace(); // Log any errors
            JOptionPane.showMessageDialog(new JFrame(), "Error sending message to LINE: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String truncateMessage(String message, int maxLength) {
        if (message.length() > maxLength) {
            return message.substring(0, maxLength - 3) + "..."; // Truncate and add ellipsis if message is too long
        } else {
            return message; // If the message is within the limit, return it as is
        }
    }

    private void sendAdminEmailToAll(String tittle, java.sql.Date sqlDate, String venue, String supervisor, String organization, String category, String rundown, String jobDetails) {
        try {
            // Query all users with the "admin" role
            String adminQuery = "SELECT \"email\" FROM \"user\" WHERE \"role\" = 'admin'";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(adminQuery);

            // Prepare email details
            String subject = "🚨 NEW EVENT ALERT 🚨 — Because You Love Jobs That Make You Happy 💕";
            String bodyEmail = "🎉 Hold on tight, a new event has just been created by none other than the fabulous " + fullName + " 🎉!\n\n" +
                               "Here are the details of this once-in-a-lifetime event:\n\n" +
                               "📝 Event Title: " + tittle + "\n" +
                               "📅 Date: " + sqlDate + "\n" +
                               "🏟️ Venue: " + venue + "\n" +
                               "👩‍🏫 Supervisor: " + supervisor + "\n" +
                               "💼 Organization: " + organization + "\n" +
                               "🎨 Category: " + category + "\n" +
                               "📜 Rundown: " + rundown + "\n\n" +
                               "But wait, there’s more! These jobs are up for grabs:\n\n" + jobDetails;

            // Send email to each admin user
            while (rs.next()) {
                String adminEmail = rs.getString("email");
                sendEmailToAdmin(adminEmail, subject, bodyEmail); // Method to send email
            }

            rs.close();
            stmt.close();

        } catch (Exception e) {
            e.printStackTrace();  // This will show the exact error in the console
            JOptionPane.showMessageDialog(this, "Error sending email to admins: " + e.getMessage());
        }
    }
    private void btn_clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clearActionPerformed
        resetForm();
        aktifButton();
        nonAktifButton();
    }//GEN-LAST:event_btn_clearActionPerformed

    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed
        if (currentEventId == -1) { // Ensure an event is selected
            JOptionPane.showMessageDialog(this, "Select a row to update");
            return;
        }

        String tittle = txtfield_tittle.getText();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String date = datechooser_date.getDate() != null ? dateFormat.format(datechooser_date.getDate()) : "";
        String venue = cb_venue.getSelectedItem().toString();
        String supervisor = txtfield_supervisor.getText();
        String organization = opt_organization.getSelectedItem().toString(); 
        String category = opt_category.getSelectedItem().toString();
        String rundown = txtfield_rundown.getText();

        // Validate form input
        if (tittle.isEmpty() || date.isEmpty() || venue.equals("Select Venue") || supervisor.isEmpty() || 
            organization.equals("Select Organization") || category.equals("Select Category") || rundown.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields must be filled out!", "Validation", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            String sql = "UPDATE \"event\" SET \"event_tittle\" = ?, \"dates\" = TO_DATE(?, 'YYYY-MM-DD'), \"venue\" = ?, \"supervisor\" = ?, \"organisasi\" = ?, \"category\" = ?, \"rundown\" = ? " +
                         "WHERE \"user_id\" = ? AND \"eventid\" = ?";
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, tittle);
            st.setString(2, date); // Ensure date matches YYYY-MM-DD format
            st.setString(3, venue);
            st.setString(4, supervisor);
            st.setString(5, organization);
            st.setString(6, category);
            st.setString(7, rundown);
            st.setInt(8, userId); 
            st.setInt(9, currentEventId); 

            int rowUpdated = st.executeUpdate();
            if (rowUpdated > 0) {
                JOptionPane.showMessageDialog(this, "Data successfully updated");
                resetForm();
                getData();
            }

            st.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error: " + e.getMessage());
        }
    }//GEN-LAST:event_btn_updateActionPerformed

    private void tbl_dataMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_dataMouseClicked
        int selectedRow = tbl_data.getSelectedRow();
        if (selectedRow != -1) {
            currentEventId = (int) tbl_data.getValueAt(selectedRow, 0); // Retrieve eventId

            // Fetch hidden fields (supervisor, organization, category, crew needs) from the database
            try {
                String sql = "SELECT e.\"supervisor\", e.\"organisasi\", e.\"category\", e.\"rundown\", e.\"display\", e.\"sound_engineer\", e.\"stage_manager\", e.\"cam_crew\", e.\"lighting\", e.\"streaming\" " +
                             "FROM \"event\" e " +
                             "WHERE e.\"eventid\" = ? AND e.\"user_id\" = ?";
                PreparedStatement st = conn.prepareStatement(sql);
                st.setInt(1, currentEventId);
                st.setInt(2, userId);
                ResultSet rs = st.executeQuery();

                if (rs.next()) {
                    String supervisor = rs.getString("supervisor");
                    String organization = rs.getString("organisasi");
                    String category = rs.getString("category");
                    String rundown = rs.getString("rundown");

                    // Set the form fields
                    txtfield_tittle.setText(tbl_data.getValueAt(selectedRow, 1).toString());
                    cb_venue.setSelectedItem(tbl_data.getValueAt(selectedRow, 3).toString());
                    txtfield_supervisor.setText(supervisor);
                    opt_organization.setSelectedItem(organization);
                    opt_category.setSelectedItem(category);
                    txtfield_rundown.setText(rundown);

                    // Set the checkboxes based on database values
                    cb_display.setSelected(rs.getInt("display") == 1);
                    cb_sound.setSelected(rs.getInt("sound_engineer") == 1);
                    cb_stage.setSelected(rs.getInt("stage_manager") == 1);
                    cb_camcrew.setSelected(rs.getInt("cam_crew") == 1);
                    cb_lighting.setSelected(rs.getInt("lighting") == 1);
                    cb_stream.setSelected(rs.getInt("streaming") == 1);

                    // Convert the date String back to java.util.Date
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    java.util.Date parsedDate = dateFormat.parse(tbl_data.getValueAt(selectedRow, 2).toString());
                    datechooser_date.setDate(parsedDate); // Set the parsed Date into the JDateChooser
                }

                rs.close();
                st.close();
            } catch (Exception e) {
                e.printStackTrace();  // This will show the exact error in the console
                System.out.println("Error: " + e.getMessage());
            }

            btn_update.setEnabled(true);
            btn_add.setEnabled(false);
            btn_delete.setEnabled(true);
        }
    }//GEN-LAST:event_tbl_dataMouseClicked

    private void btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_deleteActionPerformed
        if (currentEventId == -1) { // Ensure an event is selected
            JOptionPane.showMessageDialog(this, "Select a row to delete");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this event?", "Confirmation", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                String sql = "DELETE FROM \"event\" WHERE \"user_id\" = ? AND \"eventid\" = ?";
                PreparedStatement st = conn.prepareStatement(sql);
                st.setInt(1, userId);
                st.setInt(2, currentEventId);

                int rowDeleted = st.executeUpdate();
                if (rowDeleted > 0) {
                    JOptionPane.showMessageDialog(this, "Data successfully deleted");
                    resetForm();
                    getData();
                }

                st.close();
            } catch (Exception e) {
                e.printStackTrace();  // This will show the exact error in the console
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            }
        }

        resetForm();
        getData();
        aktifButton();
        nonAktifButton();
    }//GEN-LAST:event_btn_deleteActionPerformed

    private void btn_logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_logoutActionPerformed
        // TODO add your handling code here:
        this.dispose();
        LoginPage LoginFrame = new LoginPage();
        LoginFrame.setVisible(true);
        LoginFrame.setLocationRelativeTo(null);
    }//GEN-LAST:event_btn_logoutActionPerformed

    private void cb_displayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_displayActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cb_displayActionPerformed

    private void opt_organizationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opt_organizationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_opt_organizationActionPerformed

    private void btn_backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_backActionPerformed
        // TODO add your handling code here:
        this.dispose();
        MainPage UserHomeFrame = new MainPage(userId, fullName); // Pass full name and user ID to UserHome
        UserHomeFrame.setVisible(true);
        UserHomeFrame.setLocationRelativeTo(null);
    }//GEN-LAST:event_btn_backActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                int userId = 1; // Replace with actual user ID
                new FormPage(userId, "Default User").setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Category;
    private javax.swing.JLabel EventOrder;
    private javax.swing.JPanel Header;
    private javax.swing.JLabel Images_template;
    private javax.swing.JPanel Main;
    private javax.swing.JPanel MainPanel;
    private javax.swing.JLabel NeedPHS;
    private javax.swing.JLabel Organization;
    private javax.swing.JLabel Rundown;
    private javax.swing.JLabel Supervisor;
    private javax.swing.JLabel Venue;
    private javax.swing.JButton btn_add;
    private javax.swing.JButton btn_back;
    private javax.swing.JButton btn_clear;
    private javax.swing.JButton btn_delete;
    private javax.swing.JButton btn_logout;
    private javax.swing.JButton btn_update;
    private javax.swing.JCheckBox cb_camcrew;
    private javax.swing.JCheckBox cb_display;
    private javax.swing.JCheckBox cb_lighting;
    private javax.swing.JCheckBox cb_sound;
    private javax.swing.JCheckBox cb_stage;
    private javax.swing.JCheckBox cb_stream;
    private javax.swing.JComboBox<String> cb_venue;
    private com.toedter.calendar.JDateChooser datechooser_date;
    private javax.swing.JLabel img_bg;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label_EventName;
    private javax.swing.JLabel label_FillUp;
    private javax.swing.JLabel label_eventdate;
    private javax.swing.JLabel label_greetings;
    private javax.swing.JComboBox<String> opt_category;
    private javax.swing.JComboBox<String> opt_organization;
    private javax.swing.JTable tbl_data;
    private javax.swing.JTextField txtfield_rundown;
    private javax.swing.JTextField txtfield_supervisor;
    private javax.swing.JTextField txtfield_tittle;
    // End of variables declaration//GEN-END:variables

    private void resetForm() {
        // Reset text fields
        txtfield_tittle.setText("");
        txtfield_supervisor.setText("");
        txtfield_rundown.setText("");

        // Reset date chooser
        datechooser_date.setDate(null);

        // Reset combo boxes
        cb_venue.setSelectedIndex(0);
        opt_organization.setSelectedIndex(0);
        opt_category.setSelectedIndex(0);

        // Reset checkboxes
        cb_display.setSelected(false);
        cb_sound.setSelected(false);
        cb_stage.setSelected(false);
        cb_camcrew.setSelected(false);
        cb_lighting.setSelected(false);
        cb_stream.setSelected(false);

        // Reset the current event ID
        currentEventId = -1;
    }

    private void nonAktifButton() {
        btn_update.setEnabled(false);
        btn_delete.setEnabled(false);
    }

    private void aktifButton() {
        btn_add.setEnabled(true);
        btn_clear.setEnabled(true);
    }

    
}
