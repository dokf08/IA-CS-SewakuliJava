package Interfaces;

//technique importing packages
import Config.AppConnection;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.Statement;
import java.awt.Desktop;
import javax.swing.JFileChooser;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.mail.Multipart;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import java.net.InetAddress;
import java.net.UnknownHostException;



public class JobDBPage extends javax.swing.JFrame {
    
    private int userId;
    private String fullName;
    
    public JobDBPage(int userId, String fullName) {
        initComponents();
        this.userId = userId;
        this.fullName = fullName;
        displayFullName(); // Call a method to display the full name
        loadJobSummary(); 
        loadEventDetails();
    }
    
    private void displayFullName() {
        // Assuming you have a label to show the full name
        label_greetings.setText("Hi, " + fullName);
    }
    
    
    private void loadEventDetails() {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0); 

        try {
            Connection con = AppConnection.getConnection();
            Statement st = con.createStatement();

            String query = "SELECT e.\"event_tittle\" AS event_name, e.\"dates\" AS event_date, e.\"venue\" AS event_venue, " +
                           "COALESCE(jd_display.\"crew_name\", '-') AS display, " +
                           "COALESCE(jd_sound_engineer.\"crew_name\", '-') AS sound_engineer, " +
                           "COALESCE(jd_stage_manager.\"crew_name\", '-') AS stage_manager, " +
                           "COALESCE(jd_lighting.\"crew_name\", '-') AS lighting, " +
                           "COALESCE(jd_streaming.\"crew_name\", '-') AS streaming, " +
                           "COALESCE(jd_camera.\"crew_name\", '-') AS cam_crew " +
                           "FROM \"event\" e " +
                           "LEFT JOIN \"job_info\" jd_display ON jd_display.\"event_id\" = e.\"eventid\" AND jd_display.\"job\" = 'display' " +
                           "LEFT JOIN \"job_info\" jd_sound_engineer ON jd_sound_engineer.\"event_id\" = e.\"eventid\" AND jd_sound_engineer.\"job\" = 'sound_engineer' " +
                           "LEFT JOIN \"job_info\" jd_stage_manager ON jd_stage_manager.\"event_id\" = e.\"eventid\" AND jd_stage_manager.\"job\" = 'stage_manager' " +
                           "LEFT JOIN \"job_info\" jd_lighting ON jd_lighting.\"event_id\" = e.\"eventid\" AND jd_lighting.\"job\" = 'lighting' " +
                           "LEFT JOIN \"job_info\" jd_streaming ON jd_streaming.\"event_id\" = e.\"eventid\" AND jd_streaming.\"job\" = 'streaming' " +
                           "LEFT JOIN \"job_info\" jd_camera ON jd_camera.\"event_id\" = e.\"eventid\" AND jd_camera.\"job\" = 'cam_crew'";

            ResultSet rs = st.executeQuery(query);

            while (rs.next()) {
                String eventName = rs.getString("event_name");
                String eventDate = rs.getString("event_date");
                String eventVenue = rs.getString("event_venue");
                String displayCrew = rs.getString("display");
                String soundEngineerCrew = rs.getString("sound_engineer");
                String stageManagerCrew = rs.getString("stage_manager");
                String lightingCrew = rs.getString("lighting");
                String streamingCrew = rs.getString("streaming");
                String cameraCrew = rs.getString("cam_crew");

                model.addRow(new Object[]{eventName, eventDate, eventVenue, displayCrew, soundEngineerCrew, stageManagerCrew, lightingCrew, streamingCrew, cameraCrew});
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }


    private void sendEmailWithAttachment(String crewEmail, String subject, String bodyEmail, File file) {
        String emailSender = AppConnection.getEmailSender();
        String passwordSender = AppConnection.getPasswordSender();

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(emailSender, passwordSender);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(emailSender));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(crewEmail));
            message.setSubject(subject);

            MimeBodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setText(bodyEmail);

            MimeBodyPart attachmentBodyPart = new MimeBodyPart();
            attachmentBodyPart.attachFile(file);

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);
            multipart.addBodyPart(attachmentBodyPart);

            message.setContent(multipart);
            Transport.send(message);

            System.out.println("Email with sarcastic job summary and Excel report sent to " + crewEmail);

        } catch (MessagingException | IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error sending email: " + e.getMessage());
        }
    }
    
    
    private void loadJobSummary() {
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        model.setRowCount(0);

        try {
            Connection con = AppConnection.getConnection();
            Statement st = con.createStatement();

            String query = "SELECT \"crew_name\", " +
                           "COUNT(*) AS total_jobs, " +
                           "SUM(CASE WHEN \"job\" = 'display' THEN 1 ELSE 0 END) AS display_jobs, " +
                           "SUM(CASE WHEN \"job\" = 'sound_engineer' THEN 1 ELSE 0 END) AS sound_engineer_jobs, " +
                           "SUM(CASE WHEN \"job\" = 'stage_manager' THEN 1 ELSE 0 END) AS stage_manager_jobs, " +
                           "SUM(CASE WHEN \"job\" = 'lighting' THEN 1 ELSE 0 END) AS lighting_jobs, " +
                           "SUM(CASE WHEN \"job\" = 'streaming' THEN 1 ELSE 0 END) AS streaming_jobs, " +
                           "SUM(CASE WHEN \"job\" = 'cam_crew' THEN 1 ELSE 0 END) AS camera_crew_jobs " +
                           "FROM \"job_info\" " +
                           "GROUP BY \"crew_name\"";

            ResultSet rs = st.executeQuery(query);

            while (rs.next()) {
                String crewName = rs.getString("crew_name");
                int totalJobs = rs.getInt("total_jobs");
                int displayJobs = rs.getInt("display_jobs");
                int soundEngineerJobs = rs.getInt("sound_engineer_jobs");
                int stageManagerJobs = rs.getInt("stage_manager_jobs");
                int lightingJobs = rs.getInt("lighting_jobs");
                int streamingJobs = rs.getInt("streaming_jobs");
                int cameraCrewJobs = rs.getInt("camera_crew_jobs");

                model.addRow(new Object[]{crewName, totalJobs, displayJobs, soundEngineerJobs, stageManagerJobs, lightingJobs, streamingJobs, cameraCrewJobs});
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
    
    public void openFile(String file){
        try{
            File path = new File(file);
            Desktop.getDesktop().open(path);
        }catch(IOException ioe){
            System.out.println(ioe);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        header = new javax.swing.JPanel();
        btn_back = new javax.swing.JButton();
        btn_logout = new javax.swing.JButton();
        label_greetings = new javax.swing.JLabel();
        img_header = new javax.swing.JLabel();
        main = new javax.swing.JPanel();
        btn_sendemail = new javax.swing.JButton();
        label_ExportExcel = new javax.swing.JLabel();
        label_SendEmail = new javax.swing.JLabel();
        label_CrewDetails = new javax.swing.JLabel();
        label_EventDetails = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        btn_printcrew = new javax.swing.JButton();
        img_main = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        header.setBackground(new java.awt.Color(0, 0, 0));
        header.setLayout(null);

        btn_back.setBackground(new java.awt.Color(255, 51, 255));
        btn_back.setFont(new java.awt.Font("Raleway", 1, 18)); // NOI18N
        btn_back.setForeground(new java.awt.Color(0, 0, 0));
        btn_back.setText("Back");
        btn_back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_backActionPerformed(evt);
            }
        });
        header.add(btn_back);
        btn_back.setBounds(570, 30, 100, 40);

        btn_logout.setBackground(new java.awt.Color(255, 51, 255));
        btn_logout.setFont(new java.awt.Font("Raleway", 1, 18)); // NOI18N
        btn_logout.setForeground(new java.awt.Color(0, 0, 0));
        btn_logout.setText("Logout");
        btn_logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_logoutActionPerformed(evt);
            }
        });
        header.add(btn_logout);
        btn_logout.setBounds(670, 30, 100, 40);

        label_greetings.setFont(new java.awt.Font("Raleway", 1, 24)); // NOI18N
        label_greetings.setForeground(new java.awt.Color(255, 102, 255));
        label_greetings.setText("Greetings");
        header.add(label_greetings);
        label_greetings.setBounds(90, 30, 490, 40);

        img_header.setIcon(new javax.swing.ImageIcon("/Users/dokf/Downloads/Internal Assesment CS-4.png")); // NOI18N
        img_header.setText("jLabel4");
        header.add(img_header);
        img_header.setBounds(0, -10, 800, 500);

        getContentPane().add(header);
        header.setBounds(0, 0, 800, 100);

        main.setBackground(new java.awt.Color(255, 255, 255));
        main.setLayout(null);

        btn_sendemail.setText("Send");
        btn_sendemail.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_sendemail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_sendemailActionPerformed(evt);
            }
        });
        main.add(btn_sendemail);
        btn_sendemail.setBounds(10, 110, 100, 80);

        label_ExportExcel.setFont(new java.awt.Font("Raleway", 1, 12)); // NOI18N
        label_ExportExcel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_ExportExcel.setText("Export To Excel");
        main.add(label_ExportExcel);
        label_ExportExcel.setBounds(-30, 270, 180, 17);

        label_SendEmail.setFont(new java.awt.Font("Raleway", 1, 12)); // NOI18N
        label_SendEmail.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_SendEmail.setText("Send to Email");
        main.add(label_SendEmail);
        label_SendEmail.setBounds(-20, 90, 160, 17);

        label_CrewDetails.setFont(new java.awt.Font("Raleway", 1, 18)); // NOI18N
        label_CrewDetails.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_CrewDetails.setText("Crew Details");
        main.add(label_CrewDetails);
        label_CrewDetails.setBounds(380, 0, 120, 30);

        label_EventDetails.setFont(new java.awt.Font("Raleway", 1, 18)); // NOI18N
        label_EventDetails.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_EventDetails.setText("Event Details");
        main.add(label_EventDetails);
        label_EventDetails.setBounds(380, 190, 120, 30);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Event", "Date", "Venue", "Display", "Sound Engineer", "Stage Manager", "Lighting", "Streaming", "Camera Crew"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        main.add(jScrollPane1);
        jScrollPane1.setBounds(120, 220, 660, 160);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Crew Name", "Total", "Display", "Sound Engineer", "Stage Manager", "Lighting", "Streaming", "Camera Crew"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.setColumnSelectionAllowed(true);
        jTable2.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(jTable2);
        jTable2.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        if (jTable2.getColumnModel().getColumnCount() > 0) {
            jTable2.getColumnModel().getColumn(0).setResizable(false);
            jTable2.getColumnModel().getColumn(1).setResizable(false);
            jTable2.getColumnModel().getColumn(2).setResizable(false);
            jTable2.getColumnModel().getColumn(3).setResizable(false);
            jTable2.getColumnModel().getColumn(4).setResizable(false);
            jTable2.getColumnModel().getColumn(5).setResizable(false);
            jTable2.getColumnModel().getColumn(6).setResizable(false);
            jTable2.getColumnModel().getColumn(7).setResizable(false);
        }

        main.add(jScrollPane2);
        jScrollPane2.setBounds(120, 30, 660, 160);

        btn_printcrew.setText("Export");
        btn_printcrew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_printcrewActionPerformed(evt);
            }
        });
        main.add(btn_printcrew);
        btn_printcrew.setBounds(10, 290, 100, 90);

        img_main.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/img_background.png"))); // NOI18N
        main.add(img_main);
        img_main.setBounds(0, -100, 800, 500);

        getContentPane().add(main);
        main.setBounds(0, 100, 800, 400);

        setSize(new java.awt.Dimension(800, 528));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_logoutActionPerformed
        // TODO add your handling code here:
        this.dispose();
        LoginPage LoginFrame = new LoginPage();
        LoginFrame.setVisible(true);
        LoginFrame.setLocationRelativeTo(null);
    }//GEN-LAST:event_btn_logoutActionPerformed

    private void btn_backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_backActionPerformed
        // TODO add your handling code here:
        this.dispose();
        AdminPage AdminHomeFrame = new AdminPage(fullName, userId); // Pass full name and user ID to AdminHome
        AdminHomeFrame.setVisible(true);
        AdminHomeFrame.setLocationRelativeTo(null);
    }//GEN-LAST:event_btn_backActionPerformed

    private void exportTableToSheet(JTable table, Sheet sheet) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();

        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < model.getColumnCount(); i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(model.getColumnName(i));
        }

        for (int rowIdx = 0; rowIdx < model.getRowCount(); rowIdx++) {
            Row row = sheet.createRow(rowIdx + 1);
            for (int colIdx = 0; colIdx < model.getColumnCount(); colIdx++) {
                Cell cell = row.createCell(colIdx);
                Object value = model.getValueAt(rowIdx, colIdx);

                if (value instanceof Integer) {
                    cell.setCellValue((Integer) value);
                } else if (value instanceof Double) {
                    cell.setCellValue((Double) value);
                } else {
                    cell.setCellValue(value != null ? value.toString() : "");
                }
            }
        }
    }
    
    private void btn_printcrewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_printcrewActionPerformed
        JFileChooser fileChooser = new JFileChooser();
        int option = fileChooser.showSaveDialog(this);
        if (option == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try (Workbook workbook = new XSSFWorkbook()) {
                Sheet eventSheet = workbook.createSheet("Event Details");
                Sheet crewSheet = workbook.createSheet("Crew Details");

                exportTableToSheet(jTable1, eventSheet);
                exportTableToSheet(jTable2, crewSheet);

                try (FileOutputStream fileOut = new FileOutputStream(file + ".xlsx")) {
                    workbook.write(fileOut);
                }

                openFile(file.getAbsolutePath() + ".xlsx");
                JOptionPane.showMessageDialog(null, "Exported successfully!");

            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_btn_printcrewActionPerformed

    // Method to check for internet connection by pinging google.com
    private boolean isInternetAvailable() {
        try {
            InetAddress address = InetAddress.getByName("www.google.com");
            return !address.equals("");  // If address is reachable, return true
        } catch (UnknownHostException e) {
            return false;  // If there's an issue, return false (no internet)
        }
    }
    
    private void btn_sendemailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_sendemailActionPerformed
        if (!isInternetAvailable()) {
            JOptionPane.showMessageDialog(this, "You are not connected to the internet. Please check your connection and try again.");
            return;
        }

        String emailSender = AppConnection.getEmailSender();
        String passwordSender = AppConnection.getPasswordSender();

        String subject = "Job Summary: Feeling Overwhelmed Yet? 😈";

        StringBuilder emailBody = new StringBuilder();

        // Use a writable directory like the user's home directory
        File file = new File(System.getProperty("user.home") + "/JobDBReport.xlsx");

        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet eventSheet = workbook.createSheet("Event Details");
            Sheet crewSheet = workbook.createSheet("Crew Details");

            exportTableToSheet(jTable1, eventSheet);
            exportTableToSheet(jTable2, crewSheet);

            try (FileOutputStream fileOut = new FileOutputStream(file)) {
                workbook.write(fileOut);
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
            e.printStackTrace();
            return;
        }

        try {
            Connection con = AppConnection.getConnection();
            Statement st = con.createStatement();

            String query = "SELECT \"email\" FROM \"user\" WHERE \"id\" = " + userId;
            ResultSet rs = st.executeQuery(query);

            if (rs.next()) {
                String adminEmail = rs.getString("email");

                emailBody.append("📢 Hey, admin! Ready for some scary truth? Here’s your current job summary:\n\n")
                         .append("Let's see how you're managing (or should we say... drowning in) your tasks:\n\n");

                Statement stJob = con.createStatement();
                String jobQuery = "SELECT \"crew_name\", " +
                                  "COUNT(*) AS total_jobs, " +
                                  "SUM(CASE WHEN \"job\" = 'display' THEN 1 ELSE 0 END) AS display_jobs, " +
                                  "SUM(CASE WHEN \"job\" = 'sound_engineer' THEN 1 ELSE 0 END) AS sound_engineer_jobs, " +
                                  "SUM(CASE WHEN \"job\" = 'stage_manager' THEN 1 ELSE 0 END) AS stage_manager_jobs, " +
                                  "SUM(CASE WHEN \"job\" = 'lighting' THEN 1 ELSE 0 END) AS lighting_jobs, " +
                                  "SUM(CASE WHEN \"job\" = 'streaming' THEN 1 ELSE 0 END) AS streaming_jobs, " +
                                  "SUM(CASE WHEN \"job\" = 'cam_crew' THEN 1 ELSE 0 END) AS camera_crew_jobs " +
                                  "FROM \"job_info\" WHERE \"crew_name\" = '" + fullName + "' " +
                                  "GROUP BY \"crew_name\"";

                ResultSet rsJob = stJob.executeQuery(jobQuery);

                if (rsJob.next()) {
                    int totalJobs = rsJob.getInt("total_jobs");
                    int displayJobs = rsJob.getInt("display_jobs");
                    int soundEngineerJobs = rsJob.getInt("sound_engineer_jobs");
                    int stageManagerJobs = rsJob.getInt("stage_manager_jobs");
                    int lightingJobs = rsJob.getInt("lighting_jobs");
                    int streamingJobs = rsJob.getInt("streaming_jobs");
                    int cameraCrewJobs = rsJob.getInt("camera_crew_jobs");

                    emailBody.append("Total Jobs: ").append(totalJobs).append(" – yep, you're quite busy, huh? 😏\n")
                             .append("✨ Display Jobs: ").append(displayJobs).append(" – good job, I guess.\n")
                             .append("🔊 Sound Engineer Jobs: ").append(soundEngineerJobs).append(" – you're practically an audio wizard now.\n")
                             .append("🎭 Stage Manager Jobs: ").append(stageManagerJobs).append(" – keeping everything from falling apart? Impressive.\n")
                             .append("💡 Lighting Jobs: ").append(lightingJobs).append(" – let's hope you don't leave anyone in the dark.\n")
                             .append("🎥 Streaming Jobs: ").append(streamingJobs).append(" – making everyone go viral, eh?\n")
                             .append("📸 Camera Crew Jobs: ").append(cameraCrewJobs).append(" – capturing the moments, but who's capturing yours?\n\n");
                }

                emailBody.append("Feel that cold sweat yet? 🥶 You’ve got quite the load... or is that just the beginning of your nightmares?\n")
                         .append("Check out the attached Excel report to see just how deep the job rabbit hole goes. 😱\n\n");

                sendEmailWithAttachment(adminEmail, subject, emailBody.toString(), file);

                JOptionPane.showMessageDialog(this, "Scary email sent successfully to " + adminEmail);
            } else {
                JOptionPane.showMessageDialog(this, "Error: Admin email not found.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }//GEN-LAST:event_btn_sendemailActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JobDBPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JobDBPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JobDBPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JobDBPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                int userId = 1; // Replace with actual user ID
                new JobDBPage(userId, "Default User").setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_back;
    private javax.swing.JButton btn_logout;
    private javax.swing.JButton btn_printcrew;
    private javax.swing.JButton btn_sendemail;
    private javax.swing.JPanel header;
    private javax.swing.JLabel img_header;
    private javax.swing.JLabel img_main;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JLabel label_CrewDetails;
    private javax.swing.JLabel label_EventDetails;
    private javax.swing.JLabel label_ExportExcel;
    private javax.swing.JLabel label_SendEmail;
    private javax.swing.JLabel label_greetings;
    private javax.swing.JPanel main;
    // End of variables declaration//GEN-END:variables
}
