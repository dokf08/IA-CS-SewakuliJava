package Interfaces;

import Config.AppConnection; // Import the Koneksi class
import Config.LineMessageSender;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class LoginPage extends javax.swing.JFrame {
    public LoginPage() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Main = new javax.swing.JPanel();
        LeftPanel = new javax.swing.JPanel();
        label_userlogin = new javax.swing.JLabel();
        label_email = new javax.swing.JLabel();
        label_pass = new javax.swing.JLabel();
        label_haveaccount = new javax.swing.JLabel();
        txtfield_email = new javax.swing.JTextField();
        passfield_pass = new javax.swing.JPasswordField();
        btn_login = new javax.swing.JButton();
        btn_signuppage = new javax.swing.JButton();
        cb_showpass = new javax.swing.JCheckBox();
        cb_admincheck = new javax.swing.JCheckBox();
        img_leftbg = new javax.swing.JLabel();
        img_rightbg = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Login Page");
        setBackground(new java.awt.Color(204, 204, 204));
        setPreferredSize(new java.awt.Dimension(800, 500));

        Main.setBackground(new java.awt.Color(204, 204, 204));
        Main.setPreferredSize(new java.awt.Dimension(800, 500));
        Main.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LeftPanel.setBackground(new java.awt.Color(255, 255, 255));
        LeftPanel.setPreferredSize(new java.awt.Dimension(400, 500));
        LeftPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label_userlogin.setFont(new java.awt.Font("Raleway", 1, 24)); // NOI18N
        label_userlogin.setForeground(new java.awt.Color(255, 102, 255));
        label_userlogin.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_userlogin.setText("User Login");
        LeftPanel.add(label_userlogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 65, -1, 50));

        label_email.setFont(new java.awt.Font("Raleway", 1, 18)); // NOI18N
        label_email.setText("Email :");
        LeftPanel.add(label_email, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 73, 32));

        label_pass.setFont(new java.awt.Font("Raleway", 1, 18)); // NOI18N
        label_pass.setText("Password :");
        LeftPanel.add(label_pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, -1, 32));

        label_haveaccount.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_haveaccount.setText("Don't have an account?");
        LeftPanel.add(label_haveaccount, new org.netbeans.lib.awtextra.AbsoluteConstraints(74, 414, -1, -1));

        txtfield_email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtfield_emailActionPerformed(evt);
            }
        });
        LeftPanel.add(txtfield_email, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, 340, 32));
        LeftPanel.add(passfield_pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, 340, 32));

        btn_login.setBackground(new java.awt.Color(0, 0, 0));
        btn_login.setFont(new java.awt.Font("Raleway", 1, 18)); // NOI18N
        btn_login.setForeground(new java.awt.Color(255, 102, 255));
        btn_login.setText("LOGIN");
        btn_login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_loginActionPerformed(evt);
            }
        });
        LeftPanel.add(btn_login, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 336, 340, -1));

        btn_signuppage.setFont(new java.awt.Font("Raleway", 0, 14)); // NOI18N
        btn_signuppage.setForeground(new java.awt.Color(255, 102, 255));
        btn_signuppage.setText("Sign up");
        btn_signuppage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_signuppageActionPerformed(evt);
            }
        });
        LeftPanel.add(btn_signuppage, new org.netbeans.lib.awtextra.AbsoluteConstraints(218, 410, 96, -1));

        cb_showpass.setText("Show Password");
        cb_showpass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_showpassActionPerformed(evt);
            }
        });
        LeftPanel.add(cb_showpass, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 282, 260, -1));

        cb_admincheck.setText("Login as PHS Member");
        cb_admincheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_admincheckActionPerformed(evt);
            }
        });
        LeftPanel.add(cb_admincheck, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 309, 280, -1));

        img_leftbg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/img_loginpage.png"))); // NOI18N
        LeftPanel.add(img_leftbg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, -1));

        Main.add(LeftPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        img_rightbg.setIcon(new javax.swing.ImageIcon("/Users/dokf/Downloads/Login Page.png")); // NOI18N
        Main.add(img_rightbg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Main, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Main, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        getAccessibleContext().setAccessibleName("Login");

        setSize(new java.awt.Dimension(800, 528));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtfield_emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfield_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtfield_emailActionPerformed

    
    private void btn_loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_loginActionPerformed
        String Email, Password, query, passDb = null, roleDb = null, fullName = null;
        int userId = -1; // Variable to store user ID
        int notFound = 0;

        try {
            // Use Koneksi class to get the connection
            Connection con = AppConnection.getConnection();
            Statement st = con.createStatement();

            if ("".equals(txtfield_email.getText())) {
                JOptionPane.showMessageDialog(new JFrame(), "Email Address is required", "Error", JOptionPane.ERROR_MESSAGE);
            } else if ("".equals(passfield_pass.getText())) {
                JOptionPane.showMessageDialog(new JFrame(), "Password is required", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                Email = txtfield_email.getText();
                Password = passfield_pass.getText();

                // Adjust query for PostgreSQL (case-sensitive and quotes for identifiers)
                query = "SELECT * FROM \"user\" WHERE \"email\" = '" + Email + "'";

                ResultSet rs = st.executeQuery(query);

                while (rs.next()) {
                    passDb = rs.getString("password");     // Adjusted: case-sensitive field names in PostgreSQL
                    roleDb = rs.getString("role");         // Assuming "role" column in the database
                    fullName = rs.getString("full_name");  // Assuming "full_name" column in the database
                    userId = rs.getInt("id");              // Get user ID from the database
                    notFound = 1;
                }

                // Verify login details
                if (notFound == 1 && Password.equals(passDb)) {
                    if (cb_admincheck.isSelected()) { // Admin checkbox is selected
                        if ("admin".equals(roleDb)) { // Admin trying to access PHS Member page
                            this.dispose();
                            AdminPage AdminHomeFrame = new AdminPage(fullName, userId); // Pass full name and user ID to AdminHome
                            AdminHomeFrame.setVisible(true);
                            AdminHomeFrame.setLocationRelativeTo(null);
                        } else { // Normal user trying to access admin page
                            JOptionPane.showMessageDialog(new JFrame(), "Only admins can access this section", "Access Denied", JOptionPane.ERROR_MESSAGE);
                        }
                    } else { // Normal login (non-admin mode)
                        if ("user".equals(roleDb)) { // Normal user login
                            this.dispose();
                            MainPage UserHomeFrame = new MainPage(userId, fullName); // Pass full name and user ID to UserHome
                            UserHomeFrame.setVisible(true);
                            UserHomeFrame.setLocationRelativeTo(null);
                        } else if ("admin".equals(roleDb)) { // Admin accessing as normal user
                            this.dispose();
                            MainPage AdminAsUserFrame = new MainPage(userId, fullName); // Admin accessing normal user page
                            AdminAsUserFrame.setVisible(true);
                            AdminAsUserFrame.setLocationRelativeTo(null);
                        } else {
                            JOptionPane.showMessageDialog(new JFrame(), "Incorrect email or password", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(new JFrame(), "Incorrect email or password", "Error", JOptionPane.ERROR_MESSAGE);
                }
                passfield_pass.setText(""); // Clear the password field after attempt
            }
        } catch (Exception e) {
            e.printStackTrace();  // This will show the exact error in the console
            System.out.println("Error: " + e.getMessage());
        }
    }//GEN-LAST:event_btn_loginActionPerformed

    private void btn_signuppageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_signuppageActionPerformed
        // TODO add your handling code here:
        this.dispose();
        SignUpPage SignUpFrame = new SignUpPage();
        SignUpFrame.setVisible(true);
        SignUpFrame.setLocationRelativeTo(null);
    }//GEN-LAST:event_btn_signuppageActionPerformed

    private void cb_showpassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_showpassActionPerformed
        // TODO add your handling code here:
        if(cb_showpass.isSelected()){
            passfield_pass.setEchoChar((char)0);
        } else{
            passfield_pass.setEchoChar('*');
        }
    }//GEN-LAST:event_cb_showpassActionPerformed

    private void cb_admincheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_admincheckActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_cb_admincheckActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel LeftPanel;
    private javax.swing.JPanel Main;
    private javax.swing.JButton btn_login;
    private javax.swing.JButton btn_signuppage;
    private javax.swing.JCheckBox cb_admincheck;
    private javax.swing.JCheckBox cb_showpass;
    private javax.swing.JLabel img_leftbg;
    private javax.swing.JLabel img_rightbg;
    private javax.swing.JLabel label_email;
    private javax.swing.JLabel label_haveaccount;
    private javax.swing.JLabel label_pass;
    private javax.swing.JLabel label_userlogin;
    private javax.swing.JPasswordField passfield_pass;
    private javax.swing.JTextField txtfield_email;
    // End of variables declaration//GEN-END:variables
}
