
package Interfaces;

import Config.AppConnection;
import java.sql.Connection;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class SignUpPage extends javax.swing.JFrame {

    public SignUpPage() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MainPanel = new javax.swing.JPanel();
        Left = new javax.swing.JPanel();
        label_signup = new javax.swing.JLabel();
        label_fullname = new javax.swing.JLabel();
        label_email = new javax.swing.JLabel();
        label_pass = new javax.swing.JLabel();
        label_haveaccount = new javax.swing.JLabel();
        passfield_pass = new javax.swing.JPasswordField();
        txtfield_fullname = new javax.swing.JTextField();
        txtfield_email = new javax.swing.JTextField();
        btn_signup = new javax.swing.JButton();
        btn_loginpages = new javax.swing.JButton();
        img_leftbg = new javax.swing.JLabel();
        img_rightbg = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sign Up Page");
        setBackground(new java.awt.Color(204, 204, 204));

        MainPanel.setBackground(new java.awt.Color(204, 204, 204));
        MainPanel.setPreferredSize(new java.awt.Dimension(800, 500));
        MainPanel.setLayout(null);

        Left.setBackground(new java.awt.Color(255, 255, 255));
        Left.setPreferredSize(new java.awt.Dimension(400, 500));
        Left.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label_signup.setFont(new java.awt.Font("Raleway", 1, 24)); // NOI18N
        label_signup.setForeground(new java.awt.Color(255, 102, 255));
        label_signup.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_signup.setText("Sign Up");
        Left.add(label_signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 60, 170, 50));

        label_fullname.setFont(new java.awt.Font("Raleway", 1, 18)); // NOI18N
        label_fullname.setText("Full Name :");
        Left.add(label_fullname, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 105, 32));

        label_email.setFont(new java.awt.Font("Raleway", 1, 18)); // NOI18N
        label_email.setText("Email :");
        Left.add(label_email, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 105, 32));

        label_pass.setFont(new java.awt.Font("Raleway", 1, 18)); // NOI18N
        label_pass.setText("Password :");
        Left.add(label_pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 105, 32));

        label_haveaccount.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        label_haveaccount.setText("Already have account?");
        Left.add(label_haveaccount, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 407, 220, 30));
        Left.add(passfield_pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 350, 32));

        txtfield_fullname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtfield_fullnameActionPerformed(evt);
            }
        });
        Left.add(txtfield_fullname, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, 350, 32));

        txtfield_email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtfield_emailActionPerformed(evt);
            }
        });
        Left.add(txtfield_email, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 350, 32));

        btn_signup.setBackground(new java.awt.Color(0, 0, 0));
        btn_signup.setFont(new java.awt.Font("Raleway", 1, 18)); // NOI18N
        btn_signup.setForeground(new java.awt.Color(255, 102, 255));
        btn_signup.setText("Sign Up");
        btn_signup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_signupActionPerformed(evt);
            }
        });
        Left.add(btn_signup, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 346, 350, -1));

        btn_loginpages.setForeground(new java.awt.Color(255, 102, 255));
        btn_loginpages.setText("Login");
        btn_loginpages.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_loginpagesActionPerformed(evt);
            }
        });
        Left.add(btn_loginpages, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 410, -1, -1));

        img_leftbg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/img_loginpage.png"))); // NOI18N
        Left.add(img_leftbg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, -1));

        MainPanel.add(Left);
        Left.setBounds(0, 0, 400, 500);

        img_rightbg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/img_loginpage.png"))); // NOI18N
        MainPanel.add(img_rightbg);
        img_rightbg.setBounds(0, 0, 800, 500);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        setSize(new java.awt.Dimension(800, 528));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtfield_fullnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfield_fullnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtfield_fullnameActionPerformed

    private void txtfield_emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfield_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtfield_emailActionPerformed

    private void btn_signupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_signupActionPerformed
        String fullName, email, Password, query;

        try {
            // Use Koneksi class to get the connection
            Connection con = AppConnection.getConnection();
            Statement st = con.createStatement();

            fullName = txtfield_fullname.getText();
            email = txtfield_email.getText();
            Password = passfield_pass.getText();

            // Email validation pattern using regex
            String emailPattern = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";

            // Validation
            if (fullName.isEmpty()) {
                JOptionPane.showMessageDialog(new JFrame(), "Full Name is required", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (email.isEmpty()) {
                JOptionPane.showMessageDialog(new JFrame(), "Email Address is required", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (!email.matches(emailPattern)) {
                JOptionPane.showMessageDialog(new JFrame(), "Email Address must be a valid email", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (Password.isEmpty()) {
                JOptionPane.showMessageDialog(new JFrame(), "Password is required", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (Password.length() < 8 || !Password.matches(".*[!@#$%^&*()].*")) {
                JOptionPane.showMessageDialog(new JFrame(), "Password must be at least 8 characters long and contain at least one special symbol (!@#$%^&*())", 
                        "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                // Adjusted for PostgreSQL case sensitivity and quoting identifiers
                query = "INSERT INTO \"user\"(\"full_name\", \"email\", \"password\", \"role\") " +
                        "VALUES('" + fullName + "', '" + email + "', '" + Password + "', 'user')";

                st.execute(query);
                txtfield_fullname.setText("");
                txtfield_email.setText("");
                passfield_pass.setText("");
                JOptionPane.showMessageDialog(null, "New account has been created successfully!");

                this.dispose();
                LoginPage LoginFrame = new LoginPage();
                LoginFrame.setVisible(true);
                LoginFrame.setLocationRelativeTo(null);
            }

        } catch (Exception e) {
            e.printStackTrace();  // This will show the exact error in the console
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }//GEN-LAST:event_btn_signupActionPerformed

    private void btn_loginpagesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_loginpagesActionPerformed
        // TODO add your handling code here:
        this.dispose();
        LoginPage LoginFrame = new LoginPage();
        LoginFrame.setVisible(true);
        LoginFrame.setLocationRelativeTo(null);
    }//GEN-LAST:event_btn_loginpagesActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SignUpPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SignUpPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SignUpPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SignUpPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SignUpPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Left;
    private javax.swing.JPanel MainPanel;
    private javax.swing.JButton btn_loginpages;
    private javax.swing.JButton btn_signup;
    private javax.swing.JLabel img_leftbg;
    private javax.swing.JLabel img_rightbg;
    private javax.swing.JLabel label_email;
    private javax.swing.JLabel label_fullname;
    private javax.swing.JLabel label_haveaccount;
    private javax.swing.JLabel label_pass;
    private javax.swing.JLabel label_signup;
    private javax.swing.JPasswordField passfield_pass;
    private javax.swing.JTextField txtfield_email;
    private javax.swing.JTextField txtfield_fullname;
    // End of variables declaration//GEN-END:variables
}
