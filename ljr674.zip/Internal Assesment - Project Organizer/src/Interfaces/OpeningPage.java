package Interfaces;

public class OpeningPage extends javax.swing.JFrame {

    public OpeningPage() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btn_Clickhere = new javax.swing.JButton();
        img_openingpage = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        btn_Clickhere.setBackground(new java.awt.Color(0, 0, 0));
        btn_Clickhere.setFont(new java.awt.Font("Raleway", 1, 14)); // NOI18N
        btn_Clickhere.setForeground(new java.awt.Color(255, 102, 255));
        btn_Clickhere.setText("Click Here!");
        btn_Clickhere.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ClickhereActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Clickhere);
        btn_Clickhere.setBounds(328, 423, 150, 30);

        img_openingpage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/img_openingpage.png"))); // NOI18N
        getContentPane().add(img_openingpage);
        img_openingpage.setBounds(0, 0, 800, 500);

        setSize(new java.awt.Dimension(800, 528));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_ClickhereActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ClickhereActionPerformed
        this.dispose();
        LoginPage LoginFrame = new LoginPage();
        LoginFrame.setVisible(true);
        LoginFrame.setLocationRelativeTo(null);
    }//GEN-LAST:event_btn_ClickhereActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(OpeningPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(OpeningPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(OpeningPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(OpeningPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new OpeningPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Clickhere;
    private javax.swing.JLabel img_openingpage;
    // End of variables declaration//GEN-END:variables
}
