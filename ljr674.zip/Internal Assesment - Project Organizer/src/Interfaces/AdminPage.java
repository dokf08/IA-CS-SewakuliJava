package Interfaces;


import Config.AppConnection;
import Config.StatusChecker;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class AdminPage extends javax.swing.JFrame {
    private int userId;
    private String fullName;
    private Connection conn;
    private StatusChecker statusChecker;
    
    public AdminPage(String fullName, int userId) {
        initComponents();
        this.userId = userId;
        this.fullName = fullName;
        displayFullName(); // Call a method to display the full name
        conn = AppConnection.getConnection();
        getData();
        jTextArea1.setEditable(false);
    }
    
    
    private void displayFullName() {
        // Assuming you have a label to show the full name
        label_greetings.setText("Hi, " + fullName);
    }
    
    
    private void refreshData() {
        getData(); // Fetches updated data for the table
        clearTextArea(); // Clears the JTextArea to avoid displaying old information
    }
    private void clearTextArea() {
        jTextArea1.setText(""); // Clear the existing text
    }
    
    private void getData() {
        DefaultTableModel model = (DefaultTableModel) tbl_data.getModel();
        model.setRowCount(0);  // Clear the existing table rows

        try {
            // Fetch all event data, adjusted for PostgreSQL
            String sql = "SELECT \"eventid\", \"event_tittle\", \"dates\", \"venue\", \"supervisor\", \"organisasi\", \"category\" FROM \"event\"";
            PreparedStatement st = conn.prepareStatement(sql);
            ResultSet rs = st.executeQuery();

            // Initialize the Status_checker instance
            statusChecker = new StatusChecker(conn);

            // Loop through the result set and populate the table
            while (rs.next()) {
                int eventId = rs.getInt("eventid");
                String tittle = rs.getString("event_tittle");
                String date = rs.getString("dates");
                String venue = rs.getString("venue");
                String supervisor = rs.getString("supervisor");
                String organization = rs.getString("organisasi");
                String category = rs.getString("category");

                // Check the status for this event using the Status_checker class
                statusChecker.updateEventStatus(eventId);

                // Fetch the updated status from the event table
                String statusSql = "SELECT \"status\" FROM \"event\" WHERE \"eventid\" = ?";
                PreparedStatement statusPs = conn.prepareStatement(statusSql);
                statusPs.setInt(1, eventId);
                ResultSet statusRs = statusPs.executeQuery();
                String status = "Not Full";  // Default status
                if (statusRs.next()) {
                    status = statusRs.getString("status");  // Get the current status
                }

                // Add row to the table model with updated status
                Object[] rowData = {eventId, tittle, date, venue, status};
                model.addRow(rowData);  // Add row to table model

                statusRs.close();
                statusPs.close();
            }

            rs.close();
            st.close();
        } catch (Exception e) {
            e.printStackTrace();  // This will show the exact error in the console
            System.out.println("Error: " + e.getMessage());
        }
    }

    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        JobGroup = new javax.swing.ButtonGroup();
        Main = new javax.swing.JPanel();
        Header = new javax.swing.JPanel();
        btn_logout = new javax.swing.JButton();
        btn_crewDB = new javax.swing.JButton();
        label_greetings = new javax.swing.JLabel();
        img_logo = new javax.swing.JLabel();
        MainPanel = new javax.swing.JPanel();
        tbl_scrollpane = new javax.swing.JScrollPane();
        tbl_data = new javax.swing.JTable();
        label_Event_List = new javax.swing.JLabel();
        label_Job_List = new javax.swing.JLabel();
        label_Sortby = new javax.swing.JLabel();
        label_Search_Event = new javax.swing.JLabel();
        txtfield_search = new javax.swing.JTextField();
        cb_sorting = new javax.swing.JComboBox<>();
        label_Jobchooser = new javax.swing.JLabel();
        rb_display = new javax.swing.JRadioButton();
        rb_sound = new javax.swing.JRadioButton();
        rb_stream = new javax.swing.JRadioButton();
        rb_stage = new javax.swing.JRadioButton();
        rb_cam = new javax.swing.JRadioButton();
        rb_lighting = new javax.swing.JRadioButton();
        bt_refresh = new javax.swing.JButton();
        bt_submit = new javax.swing.JButton();
        bt_update = new javax.swing.JButton();
        bt_delete = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        img_background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Main.setPreferredSize(new java.awt.Dimension(800, 500));
        Main.setLayout(null);

        Header.setBackground(new java.awt.Color(0, 0, 0));
        Header.setLayout(null);

        btn_logout.setBackground(new java.awt.Color(255, 51, 255));
        btn_logout.setFont(new java.awt.Font("Raleway", 1, 18)); // NOI18N
        btn_logout.setForeground(new java.awt.Color(0, 0, 0));
        btn_logout.setText("Logout");
        btn_logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_logoutActionPerformed(evt);
            }
        });
        Header.add(btn_logout);
        btn_logout.setBounds(670, 30, 100, 40);

        btn_crewDB.setBackground(new java.awt.Color(255, 51, 255));
        btn_crewDB.setFont(new java.awt.Font("Raleway", 1, 18)); // NOI18N
        btn_crewDB.setForeground(new java.awt.Color(0, 0, 0));
        btn_crewDB.setText("Crew Database");
        btn_crewDB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_crewDBActionPerformed(evt);
            }
        });
        Header.add(btn_crewDB);
        btn_crewDB.setBounds(470, 30, 200, 40);

        label_greetings.setFont(new java.awt.Font("Raleway", 1, 24)); // NOI18N
        label_greetings.setForeground(new java.awt.Color(255, 102, 255));
        label_greetings.setText("Greetings");
        Header.add(label_greetings);
        label_greetings.setBounds(90, 30, 490, 40);

        img_logo.setIcon(new javax.swing.ImageIcon("/Users/dokf/Downloads/Internal Assesment CS-4.png")); // NOI18N
        img_logo.setText("jLabel4");
        Header.add(img_logo);
        img_logo.setBounds(0, -10, 800, 500);

        Main.add(Header);
        Header.setBounds(0, 0, 800, 100);

        MainPanel.setBackground(new java.awt.Color(255, 255, 255));
        MainPanel.setLayout(null);

        tbl_data.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Event Name", "Date", "Venue", "Status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_data.setGridColor(new java.awt.Color(204, 204, 204));
        tbl_data.setRowHeight(30);
        tbl_data.getTableHeader().setReorderingAllowed(false);
        tbl_data.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_dataMouseClicked(evt);
            }
        });
        tbl_scrollpane.setViewportView(tbl_data);
        if (tbl_data.getColumnModel().getColumnCount() > 0) {
            tbl_data.getColumnModel().getColumn(0).setResizable(false);
            tbl_data.getColumnModel().getColumn(0).setPreferredWidth(20);
            tbl_data.getColumnModel().getColumn(2).setPreferredWidth(85);
        }

        MainPanel.add(tbl_scrollpane);
        tbl_scrollpane.setBounds(30, 90, 360, 280);

        label_Event_List.setFont(new java.awt.Font("Helvetica Neue", 1, 18)); // NOI18N
        label_Event_List.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_Event_List.setText("EVENT LIST");
        MainPanel.add(label_Event_List);
        label_Event_List.setBounds(150, 20, 120, 30);

        label_Job_List.setFont(new java.awt.Font("Helvetica Neue", 1, 18)); // NOI18N
        label_Job_List.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_Job_List.setText("JOB LIST");
        MainPanel.add(label_Job_List);
        label_Job_List.setBounds(520, 20, 120, 30);

        label_Sortby.setText("Sort By..");
        MainPanel.add(label_Sortby);
        label_Sortby.setBounds(320, 40, 110, 17);

        label_Search_Event.setText("Search event");
        MainPanel.add(label_Search_Event);
        label_Search_Event.setBounds(30, 40, 110, 17);

        txtfield_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtfield_searchActionPerformed(evt);
            }
        });
        txtfield_search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtfield_searchKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtfield_searchKeyTyped(evt);
            }
        });
        MainPanel.add(txtfield_search);
        txtfield_search.setBounds(30, 60, 290, 27);

        cb_sorting.setFont(new java.awt.Font("Helvetica Neue", 0, 10)); // NOI18N
        cb_sorting.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ID", "Name", "Dates", "Status", "Venue" }));
        cb_sorting.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_sortingActionPerformed(evt);
            }
        });
        MainPanel.add(cb_sorting);
        cb_sorting.setBounds(320, 60, 70, 23);

        label_Jobchooser.setFont(new java.awt.Font("Raleway", 1, 18)); // NOI18N
        label_Jobchooser.setText("Choose Your Job");
        MainPanel.add(label_Jobchooser);
        label_Jobchooser.setBounds(410, 210, 210, 17);

        JobGroup.add(rb_display);
        rb_display.setText("Display");
        rb_display.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_displayActionPerformed(evt);
            }
        });
        MainPanel.add(rb_display);
        rb_display.setBounds(410, 240, 170, 21);

        JobGroup.add(rb_sound);
        rb_sound.setText("Sound Engineer");
        MainPanel.add(rb_sound);
        rb_sound.setBounds(410, 270, 140, 21);

        JobGroup.add(rb_stream);
        rb_stream.setText("Streaming");
        MainPanel.add(rb_stream);
        rb_stream.setBounds(610, 300, 140, 21);

        JobGroup.add(rb_stage);
        rb_stage.setText("Stage Manager");
        MainPanel.add(rb_stage);
        rb_stage.setBounds(410, 300, 170, 21);

        JobGroup.add(rb_cam);
        rb_cam.setText("Camera Crew");
        MainPanel.add(rb_cam);
        rb_cam.setBounds(610, 240, 170, 21);

        JobGroup.add(rb_lighting);
        rb_lighting.setText("Lighting");
        MainPanel.add(rb_lighting);
        rb_lighting.setBounds(610, 270, 140, 21);

        bt_refresh.setText("Refresh");
        bt_refresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_refreshActionPerformed(evt);
            }
        });
        MainPanel.add(bt_refresh);
        bt_refresh.setBounds(680, 340, 90, 30);

        bt_submit.setText("Submit");
        bt_submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_submitActionPerformed(evt);
            }
        });
        MainPanel.add(bt_submit);
        bt_submit.setBounds(410, 340, 90, 30);

        bt_update.setText("Update");
        bt_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_updateActionPerformed(evt);
            }
        });
        MainPanel.add(bt_update);
        bt_update.setBounds(500, 340, 90, 30);

        bt_delete.setText("Delete");
        bt_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_deleteActionPerformed(evt);
            }
        });
        MainPanel.add(bt_delete);
        bt_delete.setBounds(590, 340, 90, 30);

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        MainPanel.add(jScrollPane2);
        jScrollPane2.setBounds(410, 50, 360, 150);

        img_background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/img_background.png"))); // NOI18N
        MainPanel.add(img_background);
        img_background.setBounds(0, -100, 800, 500);

        Main.add(MainPanel);
        MainPanel.setBounds(0, 100, 800, 400);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Main, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Main, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_logoutActionPerformed
        // TODO add your handling code here:
        this.dispose();
        LoginPage LoginFrame = new LoginPage();
        LoginFrame.setVisible(true);
        LoginFrame.setLocationRelativeTo(null);
    }//GEN-LAST:event_btn_logoutActionPerformed

    private void tbl_dataMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_dataMouseClicked
        int row = tbl_data.getSelectedRow(); // Get the selected row index
        DefaultTableModel model = (DefaultTableModel) tbl_data.getModel();

        if (row >= 0) {
            String eventId = model.getValueAt(row, 0).toString();
            String tittle = model.getValueAt(row, 1).toString();
            String date = model.getValueAt(row, 2).toString();
            String venue = model.getValueAt(row, 3).toString();

            // Fetch additional details
            try {
                String sql = "SELECT \"supervisor\", \"organisasi\", \"category\", \"display\", \"sound_engineer\", \"stage_manager\", \"cam_crew\", \"lighting\", \"streaming\" FROM \"event\" WHERE \"eventid\" = ?";
                PreparedStatement st = conn.prepareStatement(sql);
                st.setInt(1, Integer.parseInt(eventId));
                ResultSet rs = st.executeQuery();

                String supervisor = "", organization = "", category = "";
                int[] jobRequirements = new int[6];
                if (rs.next()) {
                    supervisor = rs.getString("supervisor");
                    organization = rs.getString("organisasi");
                    category = rs.getString("category");
                    // Retrieve job requirements
                    jobRequirements[0] = rs.getInt("display");
                    jobRequirements[1] = rs.getInt("sound_engineer");
                    jobRequirements[2] = rs.getInt("stage_manager");
                    jobRequirements[3] = rs.getInt("cam_crew");
                    jobRequirements[4] = rs.getInt("lighting");
                    jobRequirements[5] = rs.getInt("streaming");
                }
                rs.close();
                st.close();

                // Fetch job details
                String jobDetails = "";
                String[] jobList = {"display", "sound_engineer", "stage_manager", "cam_crew", "lighting", "streaming"};
                for (int i = 0; i < jobList.length; i++) {
                    String job = jobList[i];
                    if (jobRequirements[i] == 1) { // Check if job is required
                        String checkCrewSql = "SELECT \"crew_name\" FROM \"job_info\" WHERE \"event_id\" = ? AND \"job\" = ?";
                        PreparedStatement ps = conn.prepareStatement(checkCrewSql);
                        ps.setInt(1, Integer.parseInt(eventId));
                        ps.setString(2, job);
                        ResultSet crewRs = ps.executeQuery();

                        String crewName = crewRs.next() ? crewRs.getString("crew_name") : "Not taken";
                        jobDetails += String.format("%s : %s\n", capitalizeFirstLetter(job.replace("_", " ")), crewName);
                        crewRs.close();
                        ps.close();
                    }
                }

                // Display event details and jobs in the JTextArea
                jTextArea1.setText(String.format("Event ID: %s\nEvent Name: %s\nDate: %s\nVenue: %s\nSupervisor: %s\nOrganization: %s\nCategory: %s\nJobs:\n%s",
                        eventId, tittle, date, venue, supervisor, organization, category, jobDetails));

            } catch (Exception e) {
                e.printStackTrace();  // This will show the exact error in the console
                System.out.println("Error: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_tbl_dataMouseClicked

    private String capitalizeFirstLetter(String input) {
        if (input == null || input.isEmpty()) return input;
        return input.substring(0, 1).toUpperCase() + input.substring(1);
    }
    
    private void txtfield_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfield_searchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtfield_searchActionPerformed

    private void cb_sortingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_sortingActionPerformed
        // TODO add your handling code here:
        // Get the selected option from the combo box
        String selectedOption = (String) cb_sorting.getSelectedItem();

        // Call the method to sort the events based on the selected option
        sortEvents(selectedOption);
    }//GEN-LAST:event_cb_sortingActionPerformed

    private void sortEvents(String sortBy) {
        DefaultTableModel model = (DefaultTableModel) tbl_data.getModel();
        model.setRowCount(0); // Clear existing rows

        try {
            // Map sorting criteria to SQL column
            String column;
            switch (sortBy) {
                case "Name":
                    column = "\"event_tittle\""; // Double quotes for PostgreSQL column name
                    break;
                case "Dates":
                    column = "\"dates\""; // PostgreSQL-compatible column
                    break;
                case "Venue":
                    column = "\"venue\"";
                    break;
                case "Status":
                    column = "\"status\"";
                    break;
                default:
                    column = "\"eventid\""; // Default to event ID if no valid selection
                    break;
            }

            // Construct SQL query with sorting
            String sql = "SELECT * FROM \"event\" ORDER BY " + column; // PostgreSQL uses double quotes for column names
            PreparedStatement st = conn.prepareStatement(sql);
            ResultSet rs = st.executeQuery();

            // Add rows to the table
            while (rs.next()) {
                int eventId = rs.getInt("eventid");
                String tittle = rs.getString("event_tittle");
                String date = rs.getString("dates");
                String venue = rs.getString("venue");
                String status = rs.getString("status");

                Object[] rowData = {eventId, tittle, date, venue, status};
                model.addRow(rowData);
            }
            rs.close();
            st.close();

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error sorting data", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void txtfield_searchKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtfield_searchKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtfield_searchKeyTyped

    private void txtfield_searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtfield_searchKeyReleased
        String searchText = txtfield_search.getText().trim(); // Get the current text in the field
        searchEvent(searchText); // Call method to search and update the table
    }//GEN-LAST:event_txtfield_searchKeyReleased

    private void rb_displayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_displayActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rb_displayActionPerformed

    private void bt_refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_refreshActionPerformed
        refreshData();
    }//GEN-LAST:event_bt_refreshActionPerformed

    private void bt_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_updateActionPerformed
        int selectedRow = tbl_data.getSelectedRow(); 
        if (selectedRow >= 0) {
            DefaultTableModel model = (DefaultTableModel) tbl_data.getModel();
            int eventId = (int) model.getValueAt(selectedRow, 0); // Get selected event ID

            // Check the current job for this event
            String currentJob = ""; // You need to fetch the current job from job_info table
            try {
                String fetchJobSql = "SELECT \"job\" FROM \"job_info\" WHERE \"event_id\" = ? AND \"crew_name\" = ?";
                PreparedStatement ps = conn.prepareStatement(fetchJobSql);
                ps.setInt(1, eventId);
                ps.setString(2, fullName);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    currentJob = rs.getString("job");
                }
                rs.close();
                ps.close();
            } catch (Exception e) {
                e.printStackTrace();  // This will show the exact error in the console
                System.out.println("Error: " + e.getMessage());
            }

            // Check which job radio button is selected
            String newJob = "";
            if (rb_display.isSelected()) newJob = "display";
            else if (rb_sound.isSelected()) newJob = "sound_engineer";
            else if (rb_stage.isSelected()) newJob = "stage_manager";
            else if (rb_cam.isSelected()) newJob = "cam_crew";
            else if (rb_lighting.isSelected()) newJob = "lighting";
            else if (rb_stream.isSelected()) newJob = "streaming";

            if (!newJob.isEmpty() && !currentJob.equals(newJob)) {
                try {
                    // Update job_info table
                    String updateJobSql = "UPDATE \"job_info\" SET \"job\" = ? WHERE \"event_id\" = ? AND \"crew_name\" = ?";
                    PreparedStatement ps = conn.prepareStatement(updateJobSql);
                    ps.setString(1, newJob);
                    ps.setInt(2, eventId);
                    ps.setString(3, fullName);
                    ps.executeUpdate();
                    ps.close();

                    // Update job count in phs_job table
                    // Decrease the count for the old job
                    String decrementOldJobSql = "UPDATE \"phs_job\" SET \"" + currentJob + "\" = \"" + currentJob + "\" - 1 WHERE \"crew_name\" = ?";
                    PreparedStatement ps2 = conn.prepareStatement(decrementOldJobSql);
                    ps2.setString(1, fullName);
                    ps2.executeUpdate();
                    ps2.close();

                    // Increase the count for the new job
                    String incrementNewJobSql = "UPDATE \"phs_job\" SET \"" + newJob + "\" = \"" + newJob + "\" + 1 WHERE \"crew_name\" = ?";
                    PreparedStatement ps3 = conn.prepareStatement(incrementNewJobSql);
                    ps3.setString(1, fullName);
                    ps3.executeUpdate();
                    ps3.close();

                    // Refresh status
                    StatusChecker statusChecker = new StatusChecker(conn);
                    statusChecker.updateEventStatus(eventId);

                    JOptionPane.showMessageDialog(this, "Job updated successfully!");
                } catch (Exception e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error updating the job", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "No change detected or invalid job selection.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an event");
        }
    }//GEN-LAST:event_bt_updateActionPerformed

    private void bt_submitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_submitActionPerformed
        int selectedRow = tbl_data.getSelectedRow(); 
        if (selectedRow >= 0) {
            DefaultTableModel model = (DefaultTableModel) tbl_data.getModel();
            int eventId = (int) model.getValueAt(selectedRow, 0); // Get selected event ID

            // Check which job radio button is selected
            String selectedJob = "";
            if (rb_display.isSelected()) selectedJob = "display";
            else if (rb_sound.isSelected()) selectedJob = "sound_engineer";
            else if (rb_stage.isSelected()) selectedJob = "stage_manager";
            else if (rb_cam.isSelected()) selectedJob = "cam_crew";
            else if (rb_lighting.isSelected()) selectedJob = "lighting";
            else if (rb_stream.isSelected()) selectedJob = "streaming";

            if (!selectedJob.isEmpty()) {
                try {
                    // Check if the job is required (demanded)
                    String checkDemandSql = "SELECT \"" + selectedJob + "\" FROM \"event\" WHERE \"eventid\" = ?";
                    PreparedStatement checkStmt = conn.prepareStatement(checkDemandSql);
                    checkStmt.setInt(1, eventId);
                    ResultSet rs = checkStmt.executeQuery();

                    int jobRequired = 0; // 0 means not required, 1 means required
                    if (rs.next()) {
                        jobRequired = rs.getInt(1); // Get the required status (0 or 1)
                    }
                    rs.close();
                    checkStmt.close();

                    if (jobRequired == 1) { // Job is required
                        // Check if the selected job has already been taken by another crew member
                        String checkJobTakenSql = "SELECT \"crew_name\" FROM \"job_info\" WHERE \"event_id\" = ? AND \"job\" = ?";
                        PreparedStatement checkJobTakenStmt = conn.prepareStatement(checkJobTakenSql);
                        checkJobTakenStmt.setInt(1, eventId);
                        checkJobTakenStmt.setString(2, selectedJob);
                        ResultSet rsJobTaken = checkJobTakenStmt.executeQuery();

                        if (rsJobTaken.next()) {
                            String takenByCrew = rsJobTaken.getString("crew_name");
                            JOptionPane.showMessageDialog(this, "This job has already been taken by " + takenByCrew + ". Please select another job or event.");
                        } else {
                            // Check if the crew member has already taken a different job for this event
                            String checkJobSql = "SELECT \"job\" FROM \"job_info\" WHERE \"event_id\" = ? AND \"crew_name\" = ?";
                            PreparedStatement ps = conn.prepareStatement(checkJobSql);
                            ps.setInt(1, eventId);
                            ps.setString(2, fullName);
                            ResultSet rsJob = ps.executeQuery();

                            if (rsJob.next()) {
                                JOptionPane.showMessageDialog(this, "You have already taken a different job for this event. Please select another event.");
                            } else {
                                // Insert into job_info table (since it's not taken)
                                String insertJobSql = "INSERT INTO \"job_info\" (\"event_id\", \"crew_name\", \"job\") VALUES (?, ?, ?)";
                                PreparedStatement psInsert = conn.prepareStatement(insertJobSql);
                                psInsert.setInt(1, eventId);
                                psInsert.setString(2, fullName);
                                psInsert.setString(3, selectedJob);
                                psInsert.executeUpdate();
                                psInsert.close();

                                // Check if the crew member exists in the phs_job table
                                String checkCrewSql = "SELECT * FROM \"phs_job\" WHERE \"crew_name\" = ?";
                                PreparedStatement psCheckCrew = conn.prepareStatement(checkCrewSql);
                                psCheckCrew.setString(1, fullName);
                                ResultSet rsCrew = psCheckCrew.executeQuery();

                                if (!rsCrew.next()) {
                                    // Crew member does not exist, insert them into phs_job table
                                    String insertCrewSql = "INSERT INTO \"phs_job\" (\"crew_name\", \"display\", \"sound_engineer\", \"stage_manager\", \"cam_crew\", \"lighting\", \"streaming\") VALUES (?, 0, 0, 0, 0, 0, 0)";
                                    PreparedStatement psInsertCrew = conn.prepareStatement(insertCrewSql);
                                    psInsertCrew.setString(1, fullName);
                                    psInsertCrew.executeUpdate();
                                    psInsertCrew.close();
                                }
                                rsCrew.close();
                                psCheckCrew.close();

                                // Update phs_job table to count the number of jobs taken by the crew
                                String updateJobCountSql = "UPDATE \"phs_job\" SET \"" + selectedJob + "\" = \"" + selectedJob + "\" + 1 WHERE \"crew_name\" = ?";
                                PreparedStatement psUpdate = conn.prepareStatement(updateJobCountSql);
                                psUpdate.setString(1, fullName);
                                psUpdate.executeUpdate();
                                psUpdate.close();

                                // Refresh status
                                StatusChecker statusChecker = new StatusChecker(conn);
                                statusChecker.updateEventStatus(eventId);

                                JOptionPane.showMessageDialog(this, "Job taken successfully!");
                            }
                            rsJob.close();
                            ps.close();
                        }
                        rsJobTaken.close();
                        checkJobTakenStmt.close();

                    } else {
                        JOptionPane.showMessageDialog(this, "This job is not required for this event.");
                    }
                } catch (Exception e) {
                    e.printStackTrace();  // This will show the exact error in the console
                    System.out.println("Error: " + e.getMessage());
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select a job to take");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an event");
        }
    }//GEN-LAST:event_bt_submitActionPerformed

    private void bt_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_deleteActionPerformed
        int selectedRow = tbl_data.getSelectedRow(); 
        if (selectedRow >= 0) {
            DefaultTableModel model = (DefaultTableModel) tbl_data.getModel();
            int eventId = (int) model.getValueAt(selectedRow, 0); // Get selected event ID

            // Fetch the job taken by the crew member
            String jobToCancel = "";
            try {
                String fetchJobSql = "SELECT \"job\" FROM \"job_info\" WHERE \"event_id\" = ? AND \"crew_name\" = ?";
                PreparedStatement ps = conn.prepareStatement(fetchJobSql);
                ps.setInt(1, eventId);
                ps.setString(2, fullName);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    jobToCancel = rs.getString("job");
                }
                rs.close();
                ps.close();
            } catch (Exception e) {
                e.printStackTrace();  // This will show the exact error in the console
                System.out.println("Error: " + e.getMessage());
            }

            if (!jobToCancel.isEmpty()) {
                try {
                    // Delete from job_info table
                    String deleteJobSql = "DELETE FROM \"job_info\" WHERE \"event_id\" = ? AND \"crew_name\" = ?";
                    PreparedStatement ps = conn.prepareStatement(deleteJobSql);
                    ps.setInt(1, eventId);
                    ps.setString(2, fullName);
                    ps.executeUpdate();
                    ps.close();

                    // Decrease job count in phs_job table
                    String decrementJobSql = "UPDATE \"phs_job\" SET \"" + jobToCancel + "\" = \"" + jobToCancel + "\" - 1 WHERE \"crew_name\" = ?";
                    PreparedStatement ps2 = conn.prepareStatement(decrementJobSql);
                    ps2.setString(1, fullName);
                    ps2.executeUpdate();
                    ps2.close();

                    // Refresh status
                    StatusChecker statusChecker = new StatusChecker(conn);
                    statusChecker.updateEventStatus(eventId);

                    JOptionPane.showMessageDialog(this, "Job canceled successfully!");
                } catch (Exception e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error canceling the job", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "No job found to cancel");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an event");
        }
    }//GEN-LAST:event_bt_deleteActionPerformed

    private void btn_crewDBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_crewDBActionPerformed
        this.dispose();
        JobDBPage JobFrame = new JobDBPage(userId, fullName);
        JobFrame.setVisible(true);
        JobFrame.setLocationRelativeTo(null);
    }//GEN-LAST:event_btn_crewDBActionPerformed

    private void searchEvent(String searchText) {
        DefaultTableModel model = (DefaultTableModel) tbl_data.getModel(); 
        model.setRowCount(0); // Clear the table before adding filtered data

        try {
            String sql;
            PreparedStatement st;

            // If the searchText is not empty, filter the data
            if (searchText.isEmpty()) {
                // Fetch all records if the search text is empty
                sql = "SELECT * FROM \"event\""; // PostgreSQL uses double quotes for table names
                st = conn.prepareStatement(sql);
            } else {
                // Fetch matching records based on the event title (you can extend it to other columns if needed)
                sql = "SELECT * FROM \"event\" WHERE \"event_tittle\" LIKE ?";
                st = conn.prepareStatement(sql);
                st.setString(1, "%" + searchText + "%"); // Use '%' to match any event containing the search text
            }

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                int eventId = rs.getInt("eventid");
                String tittle = rs.getString("event_tittle");
                String date = rs.getString("dates");
                String venue = rs.getString("venue");
                String status = rs.getString("status");

                Object[] rowData = {eventId, tittle, date, venue, status};
                model.addRow(rowData);
            }
            rs.close();
            st.close();

        } catch (Exception e) {
            e.printStackTrace();  // This will show the exact error in the console
            System.out.println("Error: " + e.getMessage());
        }
    }

    
    public static void main(String args[]) {
    /* Set the Nimbus look and feel */
    //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
    try {
        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
            if ("Nimbus".equals(info.getName())) {
                javax.swing.UIManager.setLookAndFeel(info.getClassName());
                break;
            }
        }
    } catch (ClassNotFoundException ex) {
        java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    } catch (InstantiationException ex) {
        java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    } catch (IllegalAccessException ex) {
        java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    } catch (javax.swing.UnsupportedLookAndFeelException ex) {
        java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    }
    //</editor-fold>

    /* Create and display the form */
    java.awt.EventQueue.invokeLater(new Runnable() {
        public void run() {
            // Provide a default full name for testing
            new AdminPage("Default User", 1).setVisible(true);
        }
    });
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Header;
    private javax.swing.ButtonGroup JobGroup;
    private javax.swing.JPanel Main;
    private javax.swing.JPanel MainPanel;
    private javax.swing.JButton bt_delete;
    private javax.swing.JButton bt_refresh;
    private javax.swing.JButton bt_submit;
    private javax.swing.JButton bt_update;
    private javax.swing.JButton btn_crewDB;
    private javax.swing.JButton btn_logout;
    private javax.swing.JComboBox<String> cb_sorting;
    private javax.swing.JLabel img_background;
    private javax.swing.JLabel img_logo;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel label_Event_List;
    private javax.swing.JLabel label_Job_List;
    private javax.swing.JLabel label_Jobchooser;
    private javax.swing.JLabel label_Search_Event;
    private javax.swing.JLabel label_Sortby;
    private javax.swing.JLabel label_greetings;
    private javax.swing.JRadioButton rb_cam;
    private javax.swing.JRadioButton rb_display;
    private javax.swing.JRadioButton rb_lighting;
    private javax.swing.JRadioButton rb_sound;
    private javax.swing.JRadioButton rb_stage;
    private javax.swing.JRadioButton rb_stream;
    private javax.swing.JTable tbl_data;
    private javax.swing.JScrollPane tbl_scrollpane;
    private javax.swing.JTextField txtfield_search;
    // End of variables declaration//GEN-END:variables
}
