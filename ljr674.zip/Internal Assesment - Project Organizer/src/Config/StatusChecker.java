package Config;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StatusChecker {
    private Connection conn;

    public StatusChecker(Connection conn) {
        this.conn = conn;
    }

    // Method to check if all required jobs are filled for a specific event
    public void updateEventStatus(int eventId) {
        String checkJobsSql = "SELECT display, sound_engineer, stage_manager, cam_crew, lighting, streaming FROM event WHERE eventid = ?";
        try (PreparedStatement ps = conn.prepareStatement(checkJobsSql)) {
            ps.setInt(1, eventId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    boolean allJobsFilled = true;

                    // Check if any required job is not taken
                    for (String job : new String[]{"display", "sound_engineer", "stage_manager", "cam_crew", "lighting", "streaming"}) {
                        if (rs.getInt(job) == 1 && !isJobFilled(eventId, job)) {
                            allJobsFilled = false;
                            break;
                        }
                    }

                    // Update status based on the result
                    String newStatus = allJobsFilled ? "Full" : "Not Full";
                    String updateStatusSql = "UPDATE event SET status = ? WHERE eventid = ?";
                    try (PreparedStatement updatePs = conn.prepareStatement(updateStatusSql)) {
                        updatePs.setString(1, newStatus);
                        updatePs.setInt(2, eventId);
                        updatePs.executeUpdate();
                    }

                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to check if a specific job is filled
    private boolean isJobFilled(int eventId, String job) {
        String checkJobSql = "SELECT COUNT(*) FROM job_info WHERE event_id = ? AND job = ?";
        try (PreparedStatement ps = conn.prepareStatement(checkJobSql)) {
            ps.setInt(1, eventId);
            ps.setString(2, job);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
