package Config;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.DefaultCellEditor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class ButtonEditor extends DefaultCellEditor {
    private JButton button;
    private int selectedEventId;
    private JTable table;
    private Connection conn;

    public ButtonEditor(JTable table, Connection conn) {
        super(new JTextField());
        this.table = table;
        this.conn = conn;

        button = new JButton("Details");
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fireEditingStopped(); // Stop editing immediately
                int selectedRow = table.getSelectedRow();
                selectedEventId = (int) table.getValueAt(selectedRow, 0);

                // Show the details of the selected event
                showEventDetails(selectedEventId);
            }
        });
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
        return button;
    }

    @Override
    public boolean stopCellEditing() {
        fireEditingStopped(); // Ensure it stops editing immediately when clicked
        return super.stopCellEditing();
    }

    private void showEventDetails(int eventId) {
        try {
            // Retrieve the event details from the event table
            String eventSql = "SELECT * FROM event WHERE eventid = ?";
            PreparedStatement eventSt = conn.prepareStatement(eventSql);
            eventSt.setInt(1, eventId);
            ResultSet eventRs = eventSt.executeQuery();

            if (eventRs.next()) {
                String eventTitle = eventRs.getString("event_tittle");
                String eventDate = eventRs.getString("dates");
                String eventVenue = eventRs.getString("venue");
                String eventSupervisor = eventRs.getString("supervisor");
                String eventOrganization = eventRs.getString("organisasi");
                String eventCategory = eventRs.getString("category");

                // Retrieve the names of crew members who took the jobs for this event
                String jobSql = "SELECT job, crew_name FROM job_info WHERE event_id = ?";
                PreparedStatement jobSt = conn.prepareStatement(jobSql);
                jobSt.setInt(1, eventId);
                ResultSet jobRs = jobSt.executeQuery();

                // Prepare crew details
                StringBuilder crewDetails = new StringBuilder();
                crewDetails.append("Crew members assigned:\n");
                boolean hasCrew = false;

                while (jobRs.next()) {
                    String jobType = jobRs.getString("job");
                    String crewName = jobRs.getString("crew_name");

                    // Append the job and crew name to the details
                    crewDetails.append(jobType + ": " + crewName + "\n");
                    hasCrew = true;
                }

                if (!hasCrew) {
                    crewDetails.append("No crew members assigned yet.\n");
                }

                // Display the event details along with crew names in a dialog
                JDialog dialog = new JDialog();
                dialog.setTitle("Event Details");

                String eventDetails =   "Event ID: " + eventId +
                                        "\nTitle: " + eventTitle +
                                        "\nDate: " + eventDate +
                                        "\nVenue: " + eventVenue +
                                        "\nSupervisor: " + eventSupervisor +
                                        "\nOrganization: " + eventOrganization +
                                        "\nCategory of Event: " + eventCategory +
                                        "\n\n" + crewDetails.toString();

                JTextArea textArea = new JTextArea(eventDetails);
                textArea.setEditable(false); // Make it read-only
                dialog.add(textArea);

                dialog.setSize(400, 300);
                dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
                dialog.setLocationRelativeTo(null); // Center the dialog on the screen
                dialog.setVisible(true);

                jobRs.close();
                jobSt.close();
            }

            eventRs.close();
            eventSt.close();
        } catch (Exception e) {
            e.printStackTrace();  // This will show the exact error in the console
        }
    }
}
