package Config;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class AppConnection {
    private static Connection conn;
    private static final String EMAIL_SENDER = "phsprojectorganizer@gmail.com";
    private static final String PASSWORD_SENDER = "eszy xwhw jhnq yqqc";  // App-specific password

    public static Connection getConnection() {
        try {
            if (conn == null || conn.isClosed()) {
                // Basic PostgreSQL connection string (no SSL, no auto-reconnect)
                String url = "jdbc:postgresql://aws-0-ap-southeast-1.pooler.supabase.com:6543/postgres";
                String user = "postgres.qrkqyilslkvyjnpjbwid";
                String pass = "F4rr3L08@gmail.com";
                
                // Register the PostgreSQL driver
                Class.forName("org.postgresql.Driver");  // Ensure the PostgreSQL driver is loaded
                conn = DriverManager.getConnection(url, user, pass);
                System.out.println("Connection to Supabase PostgreSQL established successfully!");
            }
        } catch (SQLException | ClassNotFoundException e) {
            System.err.println("Error during connection: " + e.getMessage());
        }
        return conn;
    }

    public static String getEmailSender() {
        return EMAIL_SENDER;
    }

    public static String getPasswordSender() {
        return PASSWORD_SENDER;
    }

    // Optional method to close the connection when done
    public static void closeConnection() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
                System.out.println("Connection closed successfully.");
            }
        } catch (SQLException e) {
            System.err.println("Error closing connection: " + e.getMessage());
        }
    }
}

