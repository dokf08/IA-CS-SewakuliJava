package Config;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class LineMessageSender {

    private static final String CHANNEL_ACCESS_TOKEN = "Sl0Uv/hGUJDWzgoa1gvDH8K7W4XDxY5+ZKNiyAvDopYeW13epo27Y4sTIGLD3/93NJ8/q8MfzrTJZphG8jPRjJxxydvQ9afw2e+EPvouz/6lEvhfld1G/FEJFOh+ZfBmSmht0YFlGL7l5N9Wa71w4gdB04t89/1O/w1cDnyilFU="; // Replace with your token
    private static final String LINE_API_URL = "https://api.line.me/v2/bot/message/push";

    public static void sendMessageToGroup(String groupId, String messageText) throws Exception {
        // Step 1: Verify the group ID and message
        if (groupId == null || groupId.isEmpty()) {
            throw new IllegalArgumentException("Group ID is missing");
        }
        if (messageText == null || messageText.isEmpty()) {
            throw new IllegalArgumentException("Message text is missing");
        }

        // Step 2: Setup HTTP Connection
        URL url = new URL(LINE_API_URL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setDoOutput(true);
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Authorization", "Bearer " + CHANNEL_ACCESS_TOKEN);

        // Step 3: JSON body of the message
        String inputJson = "{"
                + "\"to\":\"" + groupId + "\","
                + "\"messages\":["
                + "    {"
                + "      \"type\":\"text\","
                + "      \"text\":\"" + messageText + "\""
                + "    }"
                + "]"
                + "}";

        // Step 4: Log the JSON payload for debugging
        System.out.println("Sending the following payload to LINE:");
        System.out.println(inputJson);

        // Step 5: Send the request
        try (OutputStream os = conn.getOutputStream()) {
            os.write(inputJson.getBytes());
            os.flush();
        }

        // Step 6: Check the response
        int responseCode = conn.getResponseCode();
        if (responseCode != HttpURLConnection.HTTP_OK) {
            // Log the error response for further debugging
            throw new RuntimeException("Failed : HTTP error code : " + responseCode);
        }

        System.out.println("Message sent successfully to the group!");

        // Step 7: Disconnect the connection
        conn.disconnect();
    }
}